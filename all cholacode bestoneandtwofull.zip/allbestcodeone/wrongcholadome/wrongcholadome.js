// Global parameters
const dome_radius = 300;          // Inner dome radius
const second_dome_radius = 310;   // Outer dome (for reference)
let speed_factor = 0.5;

// Camera parameters
let zoom_factor = 1.0;
let camera_yaw = 0.0;
let camera_pitch = 0.0;
let lockedView = null;  // "xy", "yz", "top", or null
let segmentMode = false; // When true, use discrete segment view from inside the dome
let segmentIndex = 0;    // Index of the current segment (0 to numSegments-1)
const numSegments = 8;   // For 360°/8 = 45° increments

// Permanent track points (red points inside the dome)
let trackPoints = [];

// Webcam video and slider for patch angular span
let video;
let patchSlider;

// For trajectory timing
let lastTrajectoryTime = 0;
let trajectoryInterval = 1000; // one trajectory per second

// Buttons for view lock and mode
let btnXY, btnYZ, btnTop, btnFree, btnSegment;

function setup() {
  createCanvas(800, 600, WEBGL);
  
  // Setup webcam capture
  video = createCapture(VIDEO);
  video.size(320, 240);
  video.hide();
  
  // Create slider to control horizontal angular span (in radians) for the webcam patch.
  // Vertical span is set to 75% of horizontal (to preserve 4:3 aspect ratio).
  patchSlider = createSlider(0.1, 1.0, 0.5, 0.01);
  patchSlider.position(20, 20);
  
  // Create buttons for locking camera view
  btnXY = createButton("Lock XY");
  btnXY.position(20, 50);
  btnXY.mousePressed(() => { lockedView = "xy"; segmentMode = false; });
  
  btnYZ = createButton("Lock YZ");
  btnYZ.position(90, 50);
  btnYZ.mousePressed(() => { lockedView = "yz"; segmentMode = false; });
  
  btnTop = createButton("Lock Top");
  btnTop.position(160, 50);
  btnTop.mousePressed(() => { lockedView = "top"; segmentMode = false; });
  
  btnSegment = createButton("Segment View");
  btnSegment.position(240, 50);
  btnSegment.mousePressed(() => { 
    segmentMode = true; 
    lockedView = null; 
    // Reset to first segment.
    segmentIndex = 0; 
  });
  
  btnFree = createButton("Free View");
  btnFree.position(340, 50);
  btnFree.mousePressed(() => { 
    lockedView = null; 
    segmentMode = false; 
  });
}

function draw() {
  background(0);
  
  // If a view lock is active (XY, YZ, Top) then use those fixed views.
  // Otherwise, if segment mode is active, set camera accordingly.
  if (lockedView) {
    if (lockedView === "xy") {
      camera(0, dome_radius/2, dome_radius*2, 0, dome_radius/2, 0, 0, -1, 0);
    } else if (lockedView === "yz") {
      camera(dome_radius*2, dome_radius/2, 0, 0, dome_radius/2, 0, 0, 1, 0);
    } else if (lockedView === "top") {
      camera(0, dome_radius*2.5, 0, 0, dome_radius/2, 0, 0, 0, -1);
    }
  } else if (segmentMode) {
    // In segment mode, we want an optimal 180° FOV view of the dome interior.
    // Set perspective with 180° FOV.
    perspective(PI, width/height, 0.1, 3000);
    // Place camera at the interior center of the dome.
    let camPos = createVector(0, dome_radius/2, 0);
    // Determine view direction based on current segmentIndex.
    // Divide full circle into numSegments segments.
    let angle = segmentIndex * TWO_PI / numSegments;
    let viewDir = createVector(cos(angle), 0, sin(angle));
    // Set camera to look from the center outwards.
    camera(camPos.x, camPos.y, camPos.z, 
           camPos.x + viewDir.x, camPos.y, camPos.z + viewDir.z,
           0, 1, 0);
  } else {
    // Free view: use arrow keys to rotate the camera.
    if (keyIsDown(LEFT_ARROW)) {
      camera_yaw -= 0.02 * speed_factor;
      // In free view, also update segment mode if desired (optional)
    }
    if (keyIsDown(RIGHT_ARROW)) {
      camera_yaw += 0.02 * speed_factor;
    }
    if (keyIsDown(UP_ARROW)) {
      camera_pitch = constrain(camera_pitch - 0.02 * speed_factor, -PI/2 + 0.1, PI/2 - 0.1);
    }
    if (keyIsDown(DOWN_ARROW)) {
      camera_pitch = constrain(camera_pitch + 0.02 * speed_factor, -PI/2 + 0.1, PI/2 - 0.1);
    }
    let cam_distance = 1000 * zoom_factor;
    let camX = cam_distance * sin(camera_yaw) * cos(camera_pitch);
    let camY = cam_distance * sin(camera_pitch) + dome_radius/2;
    let camZ = cam_distance * cos(camera_yaw) * cos(camera_pitch);
    camera(camX, camY, camZ, 0, dome_radius/2, 0, 0, 1, 0);
  }
  
  // If not in segment mode, use default perspective.
  if (!segmentMode) {
    perspective(PI/3, width/height, 0.1, 3000);  // Normal 60° FOV
  }
  
  // Apply zoom by scaling the scene.
  scale(zoom_factor);
  
  // Draw dome, base, webcam patch, trajectories, and permanent track points.
  drawDome();
  drawBasePlane();
  
  let patchAngle = patchSlider.value();
  drawWebcamPatch(patchAngle);
  
  if (!segmentMode && millis() - lastTrajectoryTime > trajectoryInterval) {
    drawTrajectory();
    lastTrajectoryTime = millis();
  }
  
  drawTrackPoints();
  
  // In segment mode, use left/right arrow keys to cycle segments.
  if (segmentMode) {
    if (keyIsDown(LEFT_ARROW)) {
      segmentIndex = (segmentIndex - 1 + numSegments) % numSegments;
      delay(150);  // small delay to avoid rapid cycling
    }
    if (keyIsDown(RIGHT_ARROW)) {
      segmentIndex = (segmentIndex + 1) % numSegments;
      delay(150);
    }
  }
}

// Zoom using mouse wheel.
function mouseWheel(event) {
  zoom_factor = constrain(zoom_factor - event.delta * 0.001, 0.1, 5.0);
}

// Draw a transparent hemispherical dome (upper half)
function drawDome() {
  push();
  noStroke();
  fill(100, 100, 255, 50);
  let domeDetail = 30;
  for (let i = 0; i < domeDetail; i++) {
    let theta1 = map(i, 0, domeDetail, 0, PI/2);
    let theta2 = map(i + 1, 0, domeDetail, 0, PI/2);
    beginShape(TRIANGLE_STRIP);
    for (let j = 0; j <= domeDetail; j++) {
      let phi = map(j, 0, domeDetail, 0, TWO_PI);
      let x1 = dome_radius * sin(theta1) * cos(phi);
      let y1 = dome_radius * cos(theta1);
      let z1 = dome_radius * sin(theta1) * sin(phi);
      vertex(x1, y1, z1);
      let x2 = dome_radius * sin(theta2) * cos(phi);
      let y2 = dome_radius * cos(theta2);
      let z2 = dome_radius * sin(theta2) * sin(phi);
      vertex(x2, y2, z2);
    }
    endShape();
  }
  pop();
}

// Draw the base circle (flat plane) at y = 0.
function drawBasePlane() {
  push();
  noStroke();
  fill(150, 150, 150, 100);
  beginShape();
  let baseDetail = 100;
  for (let i = 0; i < baseDetail; i++) {
    let angle = map(i, 0, baseDetail, 0, TWO_PI);
    let x = dome_radius * cos(angle);
    let z = dome_radius * sin(angle);
    vertex(x, 0, z);
  }
  endShape(CLOSE);
  pop();
}

// Draw the webcam patch on one side of the dome's interior.
// The patch is defined in spherical coordinates with horizontal span patchAngle
// and vertical span set to patchAngle * 0.75 (to preserve 4:3 aspect ratio).
function drawWebcamPatch(patchAngle) {
  push();
  texture(video);
  noStroke();
  
  let thetaStart = 0.4;            // Starting polar angle (radians)
  let verticalSpan = patchAngle * 0.75; // Vertical span for full camera view
  let phiStart = 0;                // Starting azimuthal angle for one side
  let horizontalSpan = patchAngle; // Horizontal span
  
  let patchRows = 20;
  let patchCols = 20;
  
  for (let i = 0; i < patchRows; i++) {
    let theta0 = thetaStart + (i / patchRows) * verticalSpan;
    let theta1 = thetaStart + ((i + 1) / patchRows) * verticalSpan;
    beginShape(TRIANGLE_STRIP);
    for (let j = 0; j <= patchCols; j++) {
      let phi = phiStart + (j / patchCols) * horizontalSpan;
      
      let x1 = dome_radius * sin(theta0) * cos(phi);
      let y1 = dome_radius * cos(theta0);
      let z1 = dome_radius * sin(theta0) * sin(phi);
      let u1 = j / patchCols;
      let v1 = i / patchRows;
      vertex(x1, y1, z1, u1, v1);
      
      let x2 = dome_radius * sin(theta1) * cos(phi);
      let y2 = dome_radius * cos(theta1);
      let z2 = dome_radius * sin(theta1) * sin(phi);
      let u2 = j / patchCols;
      let v2 = (i + 1) / patchRows;
      vertex(x2, y2, z2, u2, v2);
    }
    endShape();
  }
  pop();
}

// Draw a parabolic trajectory (quadratic Bezier curve) from a random point above the dome to a random point on its base.
// The trajectory is drawn in green until its xz-projection is outside the dome, and turns red once inside.
// When red, a permanent track point is recorded.
function drawTrajectory() {
  let numSegments = 30;
  let r_start = random(dome_radius + 50, dome_radius + 150);
  let angle_start = random(TWO_PI);
  let startX = r_start * cos(angle_start);
  let startZ = r_start * sin(angle_start);
  let startY = dome_radius + 100;
  
  let r_end = random(0, dome_radius);
  let angle_end = random(TWO_PI);
  let endX = r_end * cos(angle_end);
  let endZ = r_end * sin(angle_end);
  let endY = 0;
  
  let ctrlX = (startX + endX) / 2;
  let ctrlY = (startY + endY) / 2 - 50;
  let ctrlZ = (startZ + endZ) / 2;
  
  beginShape();
  for (let i = 0; i <= numSegments; i++) {
    let t = i / numSegments;
    let x = (1 - t)**2 * startX + 2 * (1 - t) * t * ctrlX + t**2 * endX;
    let y = (1 - t)**2 * startY + 2 * (1 - t) * t * ctrlY + t**2 * endY;
    let z = (1 - t)**2 * startZ + 2 * (1 - t) * t * ctrlZ + t**2 * endZ;
    
    let rDist = sqrt(x*x + z*z);
    if (rDist < dome_radius) {
      stroke(255, 0, 0);
      trackPoints.push(createVector(x, y, z));
    } else {
      stroke(0, 255, 0);
    }
    strokeWeight(2);
    vertex(x, y, z);
  }
  endShape();
}

// Draw permanent track points as small red spheres.
function drawTrackPoints() {
  push();
  noStroke();
  fill(255, 0, 0);
  for (let v of trackPoints) {
    push();
    translate(v.x, v.y, v.z);
    sphere(3);
    pop();
  }
  pop();
}
