function setup() {

}


function draw() {

}// Global parameters
const dome_radius = 300;          // Inner dome radius
const second_dome_radius = 310;   // Outer dome (for reference)
let speed_factor = 0.5;

// Dome rotation variables (about its center)
let domeRotationX = 0; // Rotation about X axis (horizontal)
let domeRotationY = 0; // Rotation about Y axis (vertical)

// Camera parameters
let zoom_factor = 1.0;

// Trajectory timing and track points
let lastTrajectoryTime = 0;
let trajectoryInterval = 1000; // One trajectory per second
let trackPoints = [];

// Video and patch slider for the webcam patch
let video;
let patchSlider;

function setup() {
  createCanvas(800, 600, WEBGL);
  
  // Setup webcam capture for the patch
  video = createCapture(VIDEO);
  video.size(320, 240);
  video.hide();
  
  // Slider to control the horizontal angular span (in radians) of the webcam patch.
  // A larger value gives a wider angle.
  patchSlider = createSlider(0.5, 2.0, 1.0, 0.01);
  patchSlider.position(20, 20);
}

function draw() {
  background(0);
  
  // ----- Dome Rotation Control via Arrow Keys -----
  // Left/right arrow keys: rotate dome about vertical (Y) axis.
  if (keyIsDown(LEFT_ARROW)) {
    domeRotationY -= 0.02 * speed_factor;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    domeRotationY += 0.02 * speed_factor;
  }
  // Up/down arrow keys: rotate dome about horizontal (X) axis.
  if (keyIsDown(UP_ARROW)) {
    domeRotationX -= 0.02 * speed_factor;
  }
  if (keyIsDown(DOWN_ARROW)) {
    domeRotationX += 0.02 * speed_factor;
  }
  
  // ----- Fixed Camera -----
  // Place the camera inside the dome so the entire interior (and patch) is visible.
  // The camera is positioned along the Z axis and looks toward the dome's center.
  let cam_distance = 1000 * zoom_factor;
  camera(0, dome_radius/2, cam_distance, 0, dome_radius/2, 0, 0, 1, 0);
  
  // ----- Draw Dome with Embedded Webcam Patch and Trajectory -----
  // Draw the dome (with its current rotation) and the base.
  drawDome();
  drawBasePlane();
  
  // Draw a new trajectory every trajectoryInterval milliseconds.
  if (millis() - lastTrajectoryTime > trajectoryInterval) {
    drawTrajectory();
    lastTrajectoryTime = millis();
  }
  
  // Draw the permanent track points (red spheres).
  drawTrackPoints();
  
  // Draw the webcam patch on the dome wall.
  // The patch is embedded into the dome's interior wall.
  let patchAngle = patchSlider.value();
  drawWebcamPatch(patchAngle);
}

// Draw a hemispherical dome that rotates about its center.
function drawDome() {
  push();
  // Translate so that the dome's center (at y = dome_radius/2) is the pivot.
  translate(0, dome_radius/2, 0);
  // Apply rotations: first about Y (vertical), then about X (horizontal).
  rotateY(domeRotationY);
  rotateX(domeRotationX);
  // Translate back to draw the dome in place.
  translate(0, -dome_radius/2, 0);
  
  noStroke();
  fill(100, 100, 255, 50);
  let domeDetail = 30;
  for (let i = 0; i < domeDetail; i++) {
    let theta1 = map(i, 0, domeDetail, 0, PI/2);
    let theta2 = map(i + 1, 0, domeDetail, 0, PI/2);
    beginShape(TRIANGLE_STRIP);
    for (let j = 0; j <= domeDetail; j++) {
      let phi = map(j, 0, domeDetail, 0, TWO_PI);
      let x1 = dome_radius * sin(theta1) * cos(phi);
      let y1 = dome_radius * cos(theta1);
      let z1 = dome_radius * sin(theta1) * sin(phi);
      vertex(x1, y1, z1);
      
      let x2 = dome_radius * sin(theta2) * cos(phi);
      let y2 = dome_radius * cos(theta2);
      let z2 = dome_radius * sin(theta2) * sin(phi);
      vertex(x2, y2, z2);
    }
    endShape();
  }
  pop();
}

// Draw the base plane (a flat circle) at y = 0.
function drawBasePlane() {
  push();
  noStroke();
  fill(150, 150, 150, 100);
  beginShape();
  let baseDetail = 100;
  for (let i = 0; i < baseDetail; i++) {
    let angle = map(i, 0, baseDetail, 0, TWO_PI);
    let x = dome_radius * cos(angle);
    let z = dome_radius * sin(angle);
    vertex(x, 0, z);
  }
  endShape(CLOSE);
  pop();
}

// Draw a parabolic trajectory (quadratic Bézier curve) from a random point above the dome
// to a random point on the base. Before the dome (outside), it's drawn green.
// Once inside the dome (xz-distance < dome_radius), it turns red and leaves a permanent track point.
function drawTrajectory() {
  let numSegments = 30;
  
  // Starting point (outside the dome)
  let r_start = random(dome_radius + 50, dome_radius + 150);
  let angle_start = random(TWO_PI);
  let startX = r_start * cos(angle_start);
  let startZ = r_start * sin(angle_start);
  let startY = dome_radius + 100;
  
  // Ending point (on the base)
  let r_end = random(0, dome_radius);
  let angle_end = random(TWO_PI);
  let endX = r_end * cos(angle_end);
  let endZ = r_end * sin(angle_end);
  let endY = 0;
  
  // Control point for the parabolic trajectory.
  let ctrlX = (startX + endX) / 2;
  let ctrlY = (startY + endY) / 2 - 50;
  let ctrlZ = (startZ + endZ) / 2;
  
  noFill();
  beginShape();
  for (let i = 0; i <= numSegments; i++) {
    let t = i / numSegments;
    // Quadratic Bézier interpolation.
    let x = (1 - t)**2 * startX + 2 * (1 - t) * t * ctrlX + t**2 * endX;
    let y = (1 - t)**2 * startY + 2 * (1 - t) * t * ctrlY + t**2 * endY;
    let z = (1 - t)**2 * startZ + 2 * (1 - t) * t * ctrlZ + t**2 * endZ;
    
    // Compute horizontal distance from center.
    let rDist = sqrt(x * x + z * z);
    
    // If the trajectory point is inside the dome, draw in red and record a track point.
    if (rDist < dome_radius) {
      stroke(255, 0, 0);
      // Record a permanent track point.
      trackPoints.push(createVector(x, y, z));
    } else {
      stroke(0, 255, 0);
    }
    strokeWeight(2);
    vertex(x, y, z);
  }
  endShape();
}

// Draw the permanent track points (red spheres) left by trajectories inside the dome.
function drawTrackPoints() {
  push();
  noStroke();
  fill(255, 0, 0);
  for (let pt of trackPoints) {
    push();
    translate(pt.x, pt.y, pt.z);
    sphere(3);
    pop();
  }
  pop();
}

// Draw the webcam patch on the dome wall using the video texture.
// The patch is embedded on the interior of the dome, at the wall.
// Here we set thetaStart near PI/2 so that the patch appears on the wall.
function drawWebcamPatch(patchAngle) {
  push();
  // Enable the video texture.
  texture(video);
  noStroke();
  
  // Place the patch on the dome wall.
  // Set thetaStart near PI/2 (dome wall) and use patchAngle to determine its horizontal span.
  let thetaStart = PI/2 - 0.5;            // Adjust this value to position the patch vertically
  let verticalSpan = patchAngle * 0.75;     // Maintain a 4:3 aspect ratio for the patch
  let phiStart = 0;                       // Starting azimuthal angle for the patch
  let horizontalSpan = patchAngle;        // Horizontal angular span
  
  let patchRows = 20;
  let patchCols = 20;
  
  // Draw the patch as a series of triangle strips on the dome's inner surface.
  for (let i = 0; i < patchRows; i++) {
    let theta0 = thetaStart + (i / patchRows) * verticalSpan;
    let theta1 = thetaStart + ((i + 1) / patchRows) * verticalSpan;
    beginShape(TRIANGLE_STRIP);
    for (let j = 0; j <= patchCols; j++) {
      let phi = phiStart + (j / patchCols) * horizontalSpan;
      
      // Compute vertex positions on the dome wall.
      let x1 = dome_radius * sin(theta0) * cos(phi);
      let y1 = dome_radius * cos(theta0);
      let z1 = dome_radius * sin(theta0) * sin(phi);
      let u1 = j / patchCols;
      let v1 = i / patchRows;
      vertex(x1, y1, z1, u1, v1);
      
      let x2 = dome_radius * sin(theta1) * cos(phi);
      let y2 = dome_radius * cos(theta1);
      let z2 = dome_radius * sin(theta1) * sin(phi);
      let u2 = j / patchCols;
      let v2 = (i + 1) / patchRows;
      vertex(x2, y2, z2, u2, v2);
    }
    endShape();
  }
  pop();
}

// Zoom using mouse wheel.
function mouseWheel(event) {
  zoom_factor = constrain(zoom_factor - event.delta * 0.001, 0.1, 5.0);
}
