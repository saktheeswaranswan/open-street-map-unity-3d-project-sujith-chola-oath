#!/usr/bin/env python3
import cv2
import numpy as np
import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import math
import random

# -------------------------------
# Global parameters
# -------------------------------
dome_radius = 300                  # Inner dome radius
second_dome_radius = 310           # Outer dome (second dome) radius
parabola_height = 50               # Vertical control point offset for trajectories
speed_factor = 0.5

# Camera parameters
zoom_factor = 1.0
camera_yaw = 0.0
camera_pitch = 0.0

# Track point lists (permanent traces)
yellow_tracks = []   # For points within inner dome (will be drawn in yellow)
red_tracks = []      # For points in the annulus (inner dome < r <= second dome)

# Webcam texture globals
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Could not open webcam")
    exit()
texture_id = glGenTextures(1)

# Red dots initialization (on upper hemisphere of inner dome)
red_dots = []
num_red_dots = 20
for _ in range(num_red_dots):
    theta = random.uniform(0, math.pi/2)   # Only upper hemisphere.
    phi = random.uniform(0, 2*math.pi)
    x = dome_radius * math.sin(theta) * math.cos(phi)
    y = dome_radius * math.cos(theta)
    z = dome_radius * math.sin(theta) * math.sin(phi)
    red_dots.append({"pos": (x, y, z), "color": (1, 0, 0)})

# -------------------------------
# Webcam feed functions
# -------------------------------
def load_texture():
    ret, frame = cap.read()
    if not ret:
        return False
    frame = cv2.flip(frame, 0)
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame_data = frame.tobytes()
    glBindTexture(GL_TEXTURE_2D, texture_id)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, frame.shape[1], frame.shape[0],
                 0, GL_RGB, GL_UNSIGNED_BYTE, frame_data)
    return True

def draw_textured_circle(radius):
    # Draw a textured circle in the xz-plane centered at (0,0,0)
    slices = 100
    glBegin(GL_TRIANGLE_FAN)
    glTexCoord2f(0.5, 0.5)
    glVertex3f(0, 0, 0)
    for i in range(slices + 1):
        angle = 2 * math.pi * i / slices
        tx = 0.5 + 0.5 * math.cos(angle)
        ty = 0.5 + 0.5 * math.sin(angle)
        glTexCoord2f(tx, ty)
        glVertex3f(radius * math.cos(angle), 0, radius * math.sin(angle))
    glEnd()

def draw_webcam_feed():
    # Parameters for the webcam feed circle
    feed_radius = dome_radius / 4   # Adjust size as needed
    # Offset so that the feed is within the base circle of the inner dome
    offset_x = dome_radius / 2
    offset_z = 0
    if load_texture():
        glEnable(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, texture_id)
        glPushMatrix()
        # Place the textured circle on the base (y=0) with a slight upward offset to avoid z-fighting.
        glTranslatef(offset_x, 0.01, offset_z)
        glColor4f(1, 1, 1, 1)
        draw_textured_circle(feed_radius)
        glPopMatrix()
        glDisable(GL_TEXTURE_2D)

# -------------------------------
# Scene drawing functions
# -------------------------------
def draw_dome(radius):
    glColor3f(1, 1, 1)
    glBegin(GL_LINE_LOOP)
    # Draw the base circle (xz-plane, y = 0)
    for i in range(100):
        angle = 2 * math.pi * i / 100
        glVertex3f(radius * math.cos(angle), 0, radius * math.sin(angle))
    glEnd()

def draw_trajectories():
    global yellow_tracks, red_tracks
    num_segments = 30
    # Generate a trajectory that starts and ends outside the outer dome,
    # with a control point that pulls the curve toward the center.
    R_start = random.uniform(second_dome_radius + 50, second_dome_radius + 150)
    angle = random.uniform(0, 2 * math.pi)
    start = (R_start * math.cos(angle), 0, R_start * math.sin(angle))
    # End point is roughly opposite with a small random offset
    offset = random.uniform(-50, 50)
    end = (-(R_start * math.cos(angle)) + offset, 0, -(R_start * math.sin(angle)) + offset)
    control = (0, parabola_height, 0)
    
    glBegin(GL_LINE_STRIP)
    for k in range(num_segments + 1):
        t = k / num_segments
        bx = (1 - t)**2 * start[0] + 2*(1 - t)*t * control[0] + t**2 * end[0]
        by = (1 - t)**2 * start[1] + 2*(1 - t)*t * control[1] + t**2 * end[1]
        bz = (1 - t)**2 * start[2] + 2*(1 - t)*t * control[2] + t**2 * end[2]
        # Determine the xz-plane radial distance
        r = math.sqrt(bx**2 + bz**2)
        # Set color based on which zone the point is in:
        if r > second_dome_radius:
            glColor3f(1, 1, 1)  # White: outside both domes.
        elif r > dome_radius:
            glColor3f(1, 0, 0)  # Red: within second dome but outside inner dome.
            # Record permanent red track if not already recorded.
            if (bx, by, bz) not in red_tracks:
                red_tracks.append((bx, by, bz))
        else:
            glColor3f(0, 0, 1)  # Blue: inside inner dome.
            # Record permanent yellow track for inner dome.
            if (bx, by, bz) not in yellow_tracks:
                yellow_tracks.append((bx, by, bz))
        glVertex3f(bx, by, bz)
    glEnd()

def draw_track_points():
    glPointSize(6)
    # Draw permanent yellow track points (inner dome)
    glColor3f(1, 1, 0)
    glBegin(GL_POINTS)
    for pt in yellow_tracks:
        glVertex3fv(pt)
    glEnd()
    # Draw permanent red track points (second dome)
    glColor3f(1, 0, 0)
    glBegin(GL_POINTS)
    for pt in red_tracks:
        glVertex3fv(pt)
    glEnd()

def draw_red_dots():
    glPointSize(8)
    glBegin(GL_POINTS)
    for dot in red_dots:
        glColor3fv(dot["color"])
        glVertex3fv(dot["pos"])
    glEnd()

# -------------------------------
# Main loop and OpenGL setup
# -------------------------------
def main():
    global camera_yaw, camera_pitch, zoom_factor
    pygame.init()
    screen = pygame.display.set_mode((800, 600), DOUBLEBUF | OPENGL)
    pygame.display.set_caption("Webcam Feed & Trajectory Dome Interaction")
    
    glEnable(GL_DEPTH_TEST)
    glClearColor(0, 0, 0, 1)
    
    # Set up the projection matrix.
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(45, (800/600), 0.1, 3000.0)
    glMatrixMode(GL_MODELVIEW)
    
    clock = pygame.time.Clock()
    running = True
    while running:
        # Event handling
        for event in pygame.event.get():
            if event.type == QUIT:
                running = False
            if event.type == KEYDOWN:
                if event.key == K_LEFT:
                    camera_yaw -= 0.05 * speed_factor
                elif event.key == K_RIGHT:
                    camera_yaw += 0.05 * speed_factor
                elif event.key == K_UP:
                    camera_pitch = min(camera_pitch + 0.05 * speed_factor, math.pi/2 - 0.1)
                elif event.key == K_DOWN:
                    camera_pitch = max(camera_pitch - 0.05 * speed_factor, -math.pi/2 + 0.1)
                elif event.key in (K_PLUS, K_EQUALS):  # Zoom in
                    zoom_factor = max(0.1, zoom_factor - 0.1)
                elif event.key == K_MINUS:           # Zoom out
                    zoom_factor = min(5.0, zoom_factor + 0.1)
        
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()
        
        # Compute camera position so the domes and trajectories are in view.
        cam_distance = 1000 * zoom_factor
        cam_x = cam_distance * math.sin(camera_yaw) * math.cos(camera_pitch)
        cam_y = cam_distance * math.sin(camera_pitch) + dome_radius / 2.0
        cam_z = cam_distance * math.cos(camera_yaw) * math.cos(camera_pitch)
        gluLookAt(cam_x, cam_y, cam_z, 0, dome_radius/2.0, 0, 0, 1, 0)
        
        # Draw scene elements:
        # 1. Draw the inner dome and second dome (base circles)
        draw_dome(dome_radius)
        draw_dome(second_dome_radius)
        # 2. Draw the webcam feed on a textured circle at the base of the inner dome.
        draw_webcam_feed()
        # 3. Draw trajectories (with color transitions) and record track points.
        draw_trajectories()
        # 4. Draw permanent track points.
        draw_track_points()
        # 5. Draw red dots on the inner dome.
        draw_red_dots()
        
        pygame.display.flip()
        clock.tick(30)
    cap.release()
    pygame.quit()

if __name__ == "__main__":
    main()

