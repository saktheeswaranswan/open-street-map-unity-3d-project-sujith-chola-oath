#!/usr/bin/env python3
import cv2
import numpy as np
import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import math
import random

# -------------------------------
# Global parameters (adjust as desired)
# -------------------------------
dome_radius = 300        # Dome radius
grid_density = 20        # Grid density (# cells along one side)
parabola_range = 100     # Trajectory (curve) range
parabola_height = 50     # Trajectory height offset
traj_exponent = 2        # Trajectory easing exponent
mouse_rotation_speed = 0.5  # Additional rotation speed from mouse drag

# Dome transformation and camera parameters.
dome_rotation_offset = 0   # Absolute dome rotation offset (degrees)
zoom_factor = 3.0          # Zoom factor (multiplier)
camera_yaw = 0.0           # Camera yaw (controlled by arrow keys)
camera_pitch = 0.0         # Camera pitch (controlled by arrow keys)
dome_rotation = 0.0        # Additional dome rotation (via right-mouse drag)
speed_factor = 0.5         # General speed factor for rotations

# -------------------------------
# Red dot initialization – points on the dome (upper hemisphere)
# -------------------------------
red_dots = []  # Each dot is a dict with 'pos': (x,y,z) and 'color': (r,g,b)
num_red_dots = 20
for _ in range(num_red_dots):
    theta = random.uniform(0, math.pi/2)  # only upper hemisphere
    phi = random.uniform(0, 2*math.pi)
    x = dome_radius * math.sin(theta) * math.cos(phi)
    y = dome_radius * math.cos(theta)
    z = dome_radius * math.sin(theta) * math.sin(phi)
    red_dots.append({"pos": (x, y, z), "color": (1, 0, 0)})  # initially red

# -------------------------------
# Pygame/OpenGL and OpenCV setup
# -------------------------------
pygame.init()
window_width, window_height = 800, 600
pygame.display.set_mode((window_width, window_height), DOUBLEBUF | OPENGL)
pygame.display.set_caption("3D Dome with Webcam Feed, Grid & Red Dots")

gluPerspective(45, window_width/window_height, 0.1, 1000.0)
glTranslatef(0.0, 0.0, -600)

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Could not open webcam")
    exit()
texture_id = glGenTextures(1)

def load_texture():
    ret, frame = cap.read()
    if not ret:
        return False
    frame = cv2.flip(frame, 0)
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame_data = frame.tobytes()
    glBindTexture(GL_TEXTURE_2D, texture_id)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, frame.shape[1], frame.shape[0],
                 0, GL_RGB, GL_UNSIGNED_BYTE, frame_data)
    return True

def draw_textured_circle(radius, slices=100):
    glBegin(GL_TRIANGLE_FAN)
    glTexCoord2f(0.5, 0.5)
    glVertex3f(0, 0, 0)
    for i in range(slices + 1):
        angle = 2 * math.pi * i / slices
        tx = 0.5 + 0.5 * math.cos(angle)
        ty = 0.5 + 0.5 * math.sin(angle)
        glTexCoord2f(tx, ty)
        glVertex3f(radius * math.cos(angle), 0, radius * math.sin(angle))
    glEnd()

def draw_webcam_feed(dome_radius):
    glEnable(GL_TEXTURE_2D)
    if load_texture():
        glBindTexture(GL_TEXTURE_2D, texture_id)
        glColor3f(1, 1, 1)
        draw_textured_circle(dome_radius, slices=100)
    glDisable(GL_TEXTURE_2D)

def draw_dome_square_patches(dome_radius, grid):
    dx = (2 * dome_radius) / grid
    glEnable(GL_BLEND)
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
    glColor4f(0.0, 0.6, 1.0, 0.1)  # translucent blue
    for i in range(grid):
        for j in range(grid):
            x0 = -dome_radius + i * dx
            z0 = -dome_radius + j * dx
            x1 = x0 + dx
            z1 = z0 + dx
            if (x0*x0 + z0*z0 <= dome_radius**2 and
                x1*x1 + z0*z0 <= dome_radius**2 and
                x1*x1 + z1*z1 <= dome_radius**2 and
                x0*x0 + z1*z1 <= dome_radius**2):
                y0 = math.sqrt(max(0, dome_radius**2 - x0*x0 - z0*z0))
                y1 = math.sqrt(max(0, dome_radius**2 - x1*x1 - z0*z0))
                y2 = math.sqrt(max(0, dome_radius**2 - x1*x1 - z1*z1))
                y3 = math.sqrt(max(0, dome_radius**2 - x0*x0 - z1*z1))
                glBegin(GL_QUADS)
                glVertex3f(x0, y0, z0)
                glVertex3f(x1, y1, z0)
                glVertex3f(x1, y2, z1)
                glVertex3f(x0, y3, z1)
                glEnd()
    glDisable(GL_BLEND)

def draw_trajectories(dome_radius, parabola_range, parabola_height, traj_exponent):
    side = dome_radius * math.sqrt(2)
    valid_dots = []
    for i in range(20):
        for j in range(20):
            dot_x = -side/2 + (i + 0.5) * (side/20)
            dot_z = -side/2 + (j + 0.5) * (side/20)
            if dot_x**2 + dot_z**2 <= dome_radius**2:
                valid_dots.append((dot_x, dot_z))
    selected_dots = random.sample(valid_dots, min(10, len(valid_dots)))
    glLineWidth(2)
    num_segments = 30
    current_time = pygame.time.get_ticks()
    blink = (int(current_time / 200) % 2 == 0)
    for (dot_x, dot_z) in selected_dots:
        p_end = (dot_x, 0, dot_z)
        mag = math.sqrt(dot_x**2 + dot_z**2)
        if mag < 1e-3:
            continue
        dir_x = dot_x / mag
        dir_z = dot_z / mag
        H = parabola_range
        alpha = random.uniform(math.radians(20), math.radians(85))
        vertical_offset = H * math.tan(alpha)
        p0 = (dot_x + dir_x * H, vertical_offset, dot_z + dir_z * H)
        p_control = ((p0[0] + p_end[0]) / 2.0,
                     (p0[1] + p_end[1]) / 2.0 + parabola_height,
                     (p0[2] + p_end[2]) / 2.0)
        # Sample the trajectory and store points.
        sample_points = []
        glBegin(GL_LINE_STRIP)
        for k in range(num_segments + 1):
            t_linear = k / float(num_segments)
            t = (0.5 * (1 - math.cos(math.pi * t_linear))) ** traj_exponent
            bx = (1-t)**2 * p0[0] + 2*(1-t)*t * p_control[0] + t**2 * p_end[0]
            by = (1-t)**2 * p0[1] + 2*(1-t)*t * p_control[1] + t**2 * p_end[1]
            bz = (1-t)**2 * p0[2] + 2*(1-t)*t * p_control[2] + t**2 * p_end[2]
            sample_points.append((bx, by, bz))
            # Color the segment: red inside, green if outside.
            if bx**2 + by**2 + bz**2 <= dome_radius**2:
                glColor3f(1, 0, 0) if blink else glColor3f(0.5, 0, 0)
            else:
                glColor3f(0, 1, 0)
            glVertex3f(bx, by, bz)
        glEnd()
        # Draw yellow points where trajectory contacts the dome surface.
        epsilon = 5.0
        glColor3f(1, 1, 0)
        glPointSize(6)
        glBegin(GL_POINTS)
        for (bx, by, bz) in sample_points:
            dome_y = math.sqrt(max(0, dome_radius**2 - bx**2 - bz**2))
            if abs(by - dome_y) < epsilon:
                glVertex3f(bx, by, bz)
        glEnd()
        # Draw a yellow line from the origin to p_end.
        glColor3f(1, 1, 0)
        glBegin(GL_LINES)
        glVertex3f(0, 0, 0)
        glVertex3f(p_end[0], p_end[1], p_end[2])
        glEnd()
    # Draw radial reference lines.
    glColor3f(1, 1, 0)
    glBegin(GL_LINES)
    for ang in range(0, 360, 15):
        rad = math.radians(ang)
        x = dome_radius * math.cos(rad)
        z = dome_radius * math.sin(rad)
        glVertex3f(0, 0, 0)
        glVertex3f(x, 0, z)
    glEnd()

def draw_red_dots():
    glPointSize(8)
    glBegin(GL_POINTS)
    for dot in red_dots:
        glColor3fv(dot["color"])
        glVertex3fv(dot["pos"])
    glEnd()

# Helper: Project a 3D point to screen coordinates.
def project(point):
    modelview = glGetDoublev(GL_MODELVIEW_MATRIX)
    projection = glGetDoublev(GL_PROJECTION_MATRIX)
    viewport = glGetIntegerv(GL_VIEWPORT)
    winX, winY, winZ = gluProject(point[0], point[1], point[2],
                                   modelview, projection, viewport)
    return winX, viewport[3] - winY, winZ

def render_scene(dome_radius, grid, parabola_range, parabola_height):
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()
    # Set camera using zoom_factor.
    r = dome_radius * zoom_factor
    center_y = dome_radius / 2.0
    cam_x = r * math.cos(camera_pitch) * math.cos(camera_yaw)
    cam_y = center_y + r * math.sin(camera_pitch)
    cam_z = r * math.cos(camera_pitch) * math.sin(camera_yaw)
    gluLookAt(cam_x, cam_y, cam_z, 0, center_y, 0, 0, 1, 0)
    glPushMatrix()
    # Apply dome rotation offset and additional rotation from mouse drag.
    glRotatef(dome_rotation_offset, 0, 1, 0)
    glRotatef(math.degrees(dome_rotation), 0, 1, 0)
    draw_webcam_feed(dome_radius)
    draw_dome_square_patches(dome_radius, grid)
    draw_trajectories(dome_radius, parabola_range, parabola_height, traj_exponent)
    draw_red_dots()
    glPopMatrix()
    glPushMatrix()
    glColor3f(1, 0, 0)
    glPointSize(10)
    glBegin(GL_POINTS)
    glVertex3f(0, dome_radius, 0)
    glEnd()
    glPopMatrix()

# Global variables for interactive control.
dome_rotation = 0.0
rotating = False
prev_mouse_x = 0
camera_yaw = 0.0
camera_pitch = 0.0

def main():
    global dome_rotation, rotating, prev_mouse_x, camera_yaw, camera_pitch, zoom_factor, dome_rotation_offset
    pygame.init()
    pygame.display.set_mode((window_width, window_height), DOUBLEBUF | OPENGL)
    pygame.display.set_caption("3D Dome with Webcam Feed, Grid & Red Dots")
    glEnable(GL_DEPTH_TEST)
    glClearColor(0, 0, 0, 1)
    glMatrixMode(GL_PROJECTION)
    gluPerspective(45, window_width/window_height, 0.1, 1000.0)
    glMatrixMode(GL_MODELVIEW)
    
    clock = pygame.time.Clock()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == QUIT:
                running = False
            # On left mouse click, check if a red dot was clicked.
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    mx, my = event.pos
                    for dot in red_dots:
                        sx, sy, _ = project(dot["pos"])
                        if math.hypot(sx - mx, sy - my) < 10:
                            dot["color"] = (1, 1, 0)  # turn yellow
            # Right mouse button drag rotates the dome.
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 3:
                    rotating = True
                    prev_mouse_x = event.pos[0]
            if event.type == MOUSEBUTTONUP:
                if event.button == 3:
                    rotating = False
            if event.type == MOUSEMOTION and rotating:
                dx = event.pos[0] - prev_mouse_x
                dome_rotation += dx * 0.005 * speed_factor
                prev_mouse_x = event.pos[0]
            # Mouse wheel adjusts zoom.
            if event.type == pygame.MOUSEWHEEL:
                zoom_factor = max(0.5, min(5.0, zoom_factor - event.y * 0.1))
            # Arrow keys control camera orientation.
            if event.type == KEYDOWN:
                if event.key == K_LEFT:
                    camera_yaw -= 0.05 * speed_factor
                elif event.key == K_RIGHT:
                    camera_yaw += 0.05 * speed_factor
                elif event.key == K_UP:
                    camera_pitch = min(camera_pitch + 0.05 * speed_factor, math.pi/2 - 0.1)
                elif event.key == K_DOWN:
                    camera_pitch = max(camera_pitch - 0.05 * speed_factor, -math.pi/2 + 0.1)
                    
        render_scene(dome_radius, grid_density, parabola_range, parabola_height)
        pygame.display.flip()
        clock.tick(30)
    cap.release()
    pygame.quit()

if __name__ == "__main__":
    main()

