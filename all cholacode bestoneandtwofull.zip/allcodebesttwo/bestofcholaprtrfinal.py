#!/usr/bin/env python3
import cv2
import numpy as np
import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import math
import random

# -------------------------------
# Global parameters
# -------------------------------
dome_radius = 300                  # Inner dome radius
second_dome_radius = 310           # Outer dome (for reference)
speed_factor = 0.5

# Camera parameters
zoom_factor = 1.0
camera_yaw = 0.0
camera_pitch = 0.0

# Permanent trace inside the dome (recorded when trajectories fall in)
yellow_tracks = []

# -------------------------------
# Webcam texture & red dots initialization
# -------------------------------
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Could not open webcam")
    exit()
texture_id = glGenTextures(1)

# Initialize red dots on the upper hemisphere of the inner dome
red_dots = []
num_red_dots = 20
for _ in range(num_red_dots):
    theta = random.uniform(0, math.pi/2)
    phi = random.uniform(0, 2 * math.pi)
    x = dome_radius * math.sin(theta) * math.cos(phi)
    y = dome_radius * math.cos(theta)
    z = dome_radius * math.sin(theta) * math.sin(phi)
    red_dots.append({"pos": (x, y, z), "color": (1, 0, 0)})

# -------------------------------
# Texture loading from webcam
# -------------------------------
def load_texture():
    ret, frame = cap.read()
    if not ret:
        return False
    frame = cv2.flip(frame, 0)
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame_data = frame.tobytes()
    glBindTexture(GL_TEXTURE_2D, texture_id)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, frame.shape[1], frame.shape[0],
                 0, GL_RGB, GL_UNSIGNED_BYTE, frame_data)
    return True

# -------------------------------
# Draw a curved patch for the webcam feed on the interior of the dome
# -------------------------------
def draw_curved_webcam_feed_interior():
    """
    Map the live webcam feed as a texture onto a large curved patch
    embedded on the inner dome’s interior.
    
    Boundaries (in radians):
      theta: 0.3 to 1.2 (~17° to ~69° from vertical)
      phi: -π/3 to π/3 (±60° horizontally)
    """
    theta_min = 0.3  
    theta_max = 1.2  
    phi_min = -math.pi/3  
    phi_max = math.pi/3   
    num_theta = 20
    num_phi = 20

    if load_texture():
        glEnable(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, texture_id)
        glBegin(GL_QUADS)
        for i in range(num_theta):
            theta0 = theta_min + i * (theta_max - theta_min) / num_theta
            theta1 = theta_min + (i + 1) * (theta_max - theta_min) / num_theta
            for j in range(num_phi):
                phi0 = phi_min + j * (phi_max - phi_min) / num_phi
                phi1 = phi_min + (j + 1) * (phi_max - phi_min) / num_phi

                # Compute vertices on the dome using spherical coordinates.
                xA = dome_radius * math.sin(theta1) * math.cos(phi0)
                yA = dome_radius * math.cos(theta1)
                zA = dome_radius * math.sin(theta1) * math.sin(phi0)

                xB = dome_radius * math.sin(theta1) * math.cos(phi1)
                yB = dome_radius * math.cos(theta1)
                zB = dome_radius * math.sin(theta1) * math.sin(phi1)

                xC = dome_radius * math.sin(theta0) * math.cos(phi1)
                yC = dome_radius * math.cos(theta0)
                zC = dome_radius * math.sin(theta0) * math.sin(phi1)

                xD = dome_radius * math.sin(theta0) * math.cos(phi0)
                yD = dome_radius * math.cos(theta0)
                zD = dome_radius * math.sin(theta0) * math.sin(phi0)

                # Map texture coordinates from 0 to 1.
                s0 = (phi0 - phi_min) / (phi_max - phi_min)
                s1 = (phi1 - phi_min) / (phi_max - phi_min)
                t0 = (theta0 - theta_min) / (theta_max - theta_min)
                t1 = (theta1 - theta_min) / (theta_max - theta_min)

                glTexCoord2f(s0, t0); glVertex3f(xD, yD, zD)
                glTexCoord2f(s0, t1); glVertex3f(xA, yA, zA)
                glTexCoord2f(s1, t1); glVertex3f(xB, yB, zB)
                glTexCoord2f(s1, t0); glVertex3f(xC, yC, zC)
        glEnd()
        glDisable(GL_TEXTURE_2D)

# -------------------------------
# Draw a curved patch for the webcam feed on the exterior of the dome
# -------------------------------
def draw_curved_webcam_feed_exterior():
    """
    Map the live webcam feed as a texture onto a curved patch on the dome’s exterior.
    The vertex order is reversed so the texture appears correctly when viewed from outside.
    """
    theta_min = 0.3  
    theta_max = 1.2  
    phi_min = -math.pi/3  
    phi_max = math.pi/3   
    num_theta = 20
    num_phi = 20

    if load_texture():
        glEnable(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, texture_id)
        glBegin(GL_QUADS)
        for i in range(num_theta):
            theta0 = theta_min + i * (theta_max - theta_min) / num_theta
            theta1 = theta_min + (i + 1) * (theta_max - theta_min) / num_theta
            for j in range(num_phi):
                phi0 = phi_min + j * (phi_max - phi_min) / num_phi
                phi1 = phi_min + (j + 1) * (phi_max - phi_min) / num_phi

                xA = dome_radius * math.sin(theta1) * math.cos(phi0)
                yA = dome_radius * math.cos(theta1)
                zA = dome_radius * math.sin(theta1) * math.sin(phi0)

                xB = dome_radius * math.sin(theta1) * math.cos(phi1)
                yB = dome_radius * math.cos(theta1)
                zB = dome_radius * math.sin(theta1) * math.sin(phi1)

                xC = dome_radius * math.sin(theta0) * math.cos(phi1)
                yC = dome_radius * math.cos(theta0)
                zC = dome_radius * math.sin(theta0) * math.sin(phi1)

                xD = dome_radius * math.sin(theta0) * math.cos(phi0)
                yD = dome_radius * math.cos(theta0)
                zD = dome_radius * math.sin(theta0) * math.sin(phi0)

                s0 = (phi0 - phi_min) / (phi_max - phi_min)
                s1 = (phi1 - phi_min) / (phi_max - phi_min)
                t0 = (theta0 - theta_min) / (theta_max - theta_min)
                t1 = (theta1 - theta_min) / (theta_max - theta_min)

                # Reverse vertex order for exterior patch.
                glTexCoord2f(s1, t0); glVertex3f(xC, yC, zC)
                glTexCoord2f(s1, t1); glVertex3f(xB, yB, zB)
                glTexCoord2f(s0, t1); glVertex3f(xA, yA, zA)
                glTexCoord2f(s0, t0); glVertex3f(xD, yD, zD)
        glEnd()
        glDisable(GL_TEXTURE_2D)

# -------------------------------
# Dome drawing functions
# -------------------------------
def draw_inner_dome():
    # Draw a bulging, transparent hemispherical surface.
    slices = 30
    stacks = 15  # Upper hemisphere (theta from 0 to π/2)
    glEnable(GL_BLEND)
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
    glColor4f(0.5, 0.5, 0.8, 0.3)
    for i in range(stacks):
        theta0 = (i / stacks) * (math.pi / 2)
        theta1 = ((i + 1) / stacks) * (math.pi / 2)
        glBegin(GL_QUAD_STRIP)
        for j in range(slices + 1):
            phi = 2 * math.pi * j / slices
            x0 = dome_radius * math.sin(theta0) * math.cos(phi)
            y0 = dome_radius * math.cos(theta0)
            z0 = dome_radius * math.sin(theta0) * math.sin(phi)
            x1 = dome_radius * math.sin(theta1) * math.cos(phi)
            y1 = dome_radius * math.cos(theta1)
            z1 = dome_radius * math.sin(theta1) * math.sin(phi)
            glVertex3f(x0, y0, z0)
            glVertex3f(x1, y1, z1)
        glEnd()
    glDisable(GL_BLEND)

def draw_outer_dome():
    # Draw a flat circle representing the outer dome (for reference).
    glColor3f(1, 1, 1)
    glBegin(GL_LINE_LOOP)
    for i in range(100):
        angle = 2 * math.pi * i / 100
        glVertex3f(second_dome_radius * math.cos(angle), 0, second_dome_radius * math.sin(angle))
    glEnd()

def draw_red_dots():
    glPointSize(8)
    glBegin(GL_POINTS)
    for dot in red_dots:
        glColor3fv(dot["color"])
        glVertex3fv(dot["pos"])
    glEnd()

# -------------------------------
# Trajectory drawing function
# -------------------------------
def draw_trajectories():
    """
    Generate a falling trajectory from a random point above the dome toward a random point on the dome base.
    While the trajectory’s xz‑projection is outside the inner dome (r > dome_radius), it is drawn in green.
    Once it enters the dome (r <= dome_radius), it turns red and each point is recorded as a yellow track.
    """
    global yellow_tracks
    num_segments = 30

    # Start: choose a point above the dome.
    r_start = random.uniform(dome_radius + 50, second_dome_radius + 150)
    angle_start = random.uniform(0, 2 * math.pi)
    start = (r_start * math.cos(angle_start),
             dome_radius + 100,  # high above the dome
             r_start * math.sin(angle_start))

    # End: choose a point on the base inside the dome.
    r_end = random.uniform(0, dome_radius)
    angle_end = random.uniform(0, 2 * math.pi)
    end = (r_end * math.cos(angle_end),
           0,  # base of the dome
           r_end * math.sin(angle_end))
    
    # Control point: average of start and end with a downward bias.
    control = ((start[0] + end[0]) / 2,
               (start[1] + end[1]) / 2 - 50,
               (start[2] + end[2]) / 2)
    
    glBegin(GL_LINE_STRIP)
    for k in range(num_segments + 1):
        t = k / num_segments
        bx = (1 - t)**2 * start[0] + 2 * (1 - t) * t * control[0] + t**2 * end[0]
        by = (1 - t)**2 * start[1] + 2 * (1 - t) * t * control[1] + t**2 * end[1]
        bz = (1 - t)**2 * start[2] + 2 * (1 - t) * t * control[2] + t**2 * end[2]
        
        # Determine radial distance in the xz‑plane.
        r = math.sqrt(bx**2 + bz**2)
        if r > dome_radius:
            glColor3f(0, 1, 0)  # Green outside the dome.
        else:
            glColor3f(1, 0, 0)  # Red inside the dome.
            if (bx, by, bz) not in yellow_tracks:
                yellow_tracks.append((bx, by, bz))
        glVertex3f(bx, by, bz)
    glEnd()

def draw_track_points():
    glPointSize(6)
    # Draw the permanent yellow track points (inside the dome).
    glColor3f(1, 1, 0)
    glBegin(GL_POINTS)
    for pt in yellow_tracks:
        glVertex3fv(pt)
    glEnd()

# -------------------------------
# Main loop and OpenGL setup
# -------------------------------
def main():
    global camera_yaw, camera_pitch, zoom_factor
    pygame.init()
    screen = pygame.display.set_mode((800, 600), DOUBLEBUF | OPENGL)
    pygame.display.set_caption("Embedded Webcam Feed on Dome")
    
    glEnable(GL_DEPTH_TEST)
    # Disable face culling so both sides of the patches are visible.
    glDisable(GL_CULL_FACE)
    glClearColor(0, 0, 0, 1)
    
    # Set up the projection matrix.
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(45, (800 / 600), 0.1, 3000.0)
    glMatrixMode(GL_MODELVIEW)
    
    clock = pygame.time.Clock()
    running = True
    while running:
        # Process events: arrow keys for rotation, mouse wheel for zoom.
        for event in pygame.event.get():
            if event.type == QUIT:
                running = False
            if event.type == KEYDOWN:
                if event.key == K_LEFT:
                    camera_yaw -= 0.05 * speed_factor
                elif event.key == K_RIGHT:
                    camera_yaw += 0.05 * speed_factor
                elif event.key == K_UP:
                    camera_pitch = min(camera_pitch + 0.05 * speed_factor, math.pi/2 - 0.1)
                elif event.key == K_DOWN:
                    camera_pitch = max(camera_pitch - 0.05 * speed_factor, -math.pi/2 + 0.1)
            if event.type == pygame.MOUSEWHEEL:
                zoom_factor = max(0.1, min(5.0, zoom_factor - event.y * 0.1))
        
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()
        # Compute camera position.
        cam_distance = 1000 * zoom_factor
        cam_x = cam_distance * math.sin(camera_yaw) * math.cos(camera_pitch)
        cam_y = cam_distance * math.sin(camera_pitch) + dome_radius / 2.0
        cam_z = cam_distance * math.cos(camera_yaw) * math.cos(camera_pitch)
        gluLookAt(cam_x, cam_y, cam_z, 0, dome_radius / 2.0, 0, 0, 1, 0)
        
        # Draw scene elements.
        draw_inner_dome()                  # Transparent, bulging inner dome.
        draw_outer_dome()                  # Outer dome (flat circle) for reference.
        draw_curved_webcam_feed_interior()  # Webcam feed on the dome interior.
        draw_curved_webcam_feed_exterior()  # Webcam feed on the dome exterior.
        draw_trajectories()                # Falling trajectory (green outside; red inside).
        draw_track_points()                # Permanent yellow trace inside the dome.
        draw_red_dots()                    # Red dots on the inner dome.
        
        pygame.display.flip()
        clock.tick(30)
    cap.release()
    pygame.quit()

if __name__ == "__main__":
    main()

