#!/usr/bin/env python3
import cv2
import numpy as np
import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import math
import random

# -------------------------------
# Global parameters
# -------------------------------
dome_radius = 300                  # Inner dome radius
second_dome_radius = 310           # Outer dome radius
parabola_height = 50               # Vertical control point offset for trajectories
speed_factor = 0.5

# Camera parameters
zoom_factor = 1.0
camera_yaw = 0.0
camera_pitch = 0.0

# Track point lists (permanent traces)
yellow_tracks = []   # For points within inner dome (recorded as yellow)
red_tracks = []      # For points in the annulus (recorded as red)

# -------------------------------
# Webcam texture globals and red dots
# -------------------------------
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Could not open webcam")
    exit()
texture_id = glGenTextures(1)

# Initialize red dots on the upper hemisphere of the inner dome
red_dots = []
num_red_dots = 20
for _ in range(num_red_dots):
    theta = random.uniform(0, math.pi/2)   # Only upper hemisphere.
    phi = random.uniform(0, 2 * math.pi)
    x = dome_radius * math.sin(theta) * math.cos(phi)
    y = dome_radius * math.cos(theta)
    z = dome_radius * math.sin(theta) * math.sin(phi)
    red_dots.append({"pos": (x, y, z), "color": (1, 0, 0)})  # Initially red.

# -------------------------------
# Webcam feed functions
# -------------------------------
def load_texture():
    ret, frame = cap.read()
    if not ret:
        return False
    frame = cv2.flip(frame, 0)
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame_data = frame.tobytes()
    glBindTexture(GL_TEXTURE_2D, texture_id)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, frame.shape[1], frame.shape[0],
                 0, GL_RGB, GL_UNSIGNED_BYTE, frame_data)
    return True

def draw_textured_circle(radius):
    slices = 100
    glBegin(GL_TRIANGLE_FAN)
    glTexCoord2f(0.5, 0.5)
    glVertex3f(0, 0, 0)
    for i in range(slices + 1):
        angle = 2 * math.pi * i / slices
        tx = 0.5 + 0.5 * math.cos(angle)
        ty = 0.5 + 0.5 * math.sin(angle)
        glTexCoord2f(tx, ty)
        glVertex3f(radius * math.cos(angle), 0, radius * math.sin(angle))
    glEnd()

def draw_webcam_feed():
    # Draw the webcam feed on a textured circle placed at the base of the inner dome.
    feed_radius = dome_radius / 4   # Adjust size as needed
    offset_x = dome_radius / 2        # Offset so it doesn't cover the center
    offset_z = 0
    if load_texture():
        glEnable(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, texture_id)
        glPushMatrix()
        glTranslatef(offset_x, 0.01, offset_z)  # Slight upward offset to avoid z-fighting
        glColor4f(1, 1, 1, 1)
        draw_textured_circle(feed_radius)
        glPopMatrix()
        glDisable(GL_TEXTURE_2D)

# -------------------------------
# Dome and trajectory drawing functions
# -------------------------------
def draw_inner_dome():
    """
    Draw the inner dome as a bulging, hemispherical surface.
    The dome is built with evenly spaced vertices in spherical coordinates,
    and is rendered with transparency.
    """
    slices = 30
    stacks = 15  # Only for the upper hemisphere (theta: 0 to pi/2)
    glEnable(GL_BLEND)
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
    # Set a semi-transparent color (e.g., bluish with alpha 0.3)
    glColor4f(0.5, 0.5, 0.8, 0.3)
    for i in range(stacks):
        theta0 = (i / stacks) * (math.pi / 2)
        theta1 = ((i + 1) / stacks) * (math.pi / 2)
        glBegin(GL_QUAD_STRIP)
        for j in range(slices + 1):
            phi = 2 * math.pi * j / slices
            # Spherical to Cartesian conversion (using y as up)
            x0 = dome_radius * math.sin(theta0) * math.cos(phi)
            z0 = dome_radius * math.sin(theta0) * math.sin(phi)
            y0 = dome_radius * math.cos(theta0)
            x1 = dome_radius * math.sin(theta1) * math.cos(phi)
            z1 = dome_radius * math.sin(theta1) * math.sin(phi)
            y1 = dome_radius * math.cos(theta1)
            glVertex3f(x0, y0, z0)
            glVertex3f(x1, y1, z1)
        glEnd()
    glDisable(GL_BLEND)

def draw_outer_dome():
    """Draw the outer dome as a flat circle (for reference)."""
    glColor3f(1, 1, 1)
    glBegin(GL_LINE_LOOP)
    for i in range(100):
        angle = 2 * math.pi * i / 100
        glVertex3f(second_dome_radius * math.cos(angle), 0, second_dome_radius * math.sin(angle))
    glEnd()

def draw_trajectories():
    global yellow_tracks, red_tracks
    num_segments = 30
    # Generate one trajectory per frame:
    R_start = random.uniform(second_dome_radius + 50, second_dome_radius + 150)
    angle = random.uniform(0, 2 * math.pi)
    start = (R_start * math.cos(angle), 0, R_start * math.sin(angle))
    offset = random.uniform(-50, 50)
    end = (-(R_start * math.cos(angle)) + offset, 0, -(R_start * math.sin(angle)) + offset)
    control = (0, parabola_height, 0)
    
    glBegin(GL_LINE_STRIP)
    for k in range(num_segments + 1):
        t = k / num_segments
        bx = (1 - t) ** 2 * start[0] + 2 * (1 - t) * t * control[0] + t ** 2 * end[0]
        by = (1 - t) ** 2 * start[1] + 2 * (1 - t) * t * control[1] + t ** 2 * end[1]
        bz = (1 - t) ** 2 * start[2] + 2 * (1 - t) * t * control[2] + t ** 2 * end[2]
        r = math.sqrt(bx**2 + bz**2)
        # Color transition:
        # Outside outer dome: white; between inner and outer: red; inside inner: blue.
        if r > second_dome_radius:
            glColor3f(1, 1, 1)  # White
        elif r > dome_radius:
            glColor3f(1, 0, 0)  # Red
            if (bx, by, bz) not in red_tracks:
                red_tracks.append((bx, by, bz))
        else:
            glColor3f(0, 0, 1)  # Blue
            if (bx, by, bz) not in yellow_tracks:
                yellow_tracks.append((bx, by, bz))
        glVertex3f(bx, by, bz)
    glEnd()

def draw_track_points():
    glPointSize(6)
    # Draw permanent yellow track points (inside inner dome)
    glColor3f(1, 1, 0)
    glBegin(GL_POINTS)
    for pt in yellow_tracks:
        glVertex3fv(pt)
    glEnd()
    # Draw permanent red track points (outer annulus)
    glColor3f(1, 0, 0)
    glBegin(GL_POINTS)
    for pt in red_tracks:
        glVertex3fv(pt)
    glEnd()

def draw_red_dots():
    glPointSize(8)
    glBegin(GL_POINTS)
    for dot in red_dots:
        glColor3fv(dot["color"])
        glVertex3fv(dot["pos"])
    glEnd()

# -------------------------------
# Main loop and OpenGL setup
# -------------------------------
def main():
    global camera_yaw, camera_pitch, zoom_factor
    pygame.init()
    screen = pygame.display.set_mode((800, 600), DOUBLEBUF | OPENGL)
    pygame.display.set_caption("Webcam Feed, Trajectories & Transparent Bulging Inner Dome")
    
    glEnable(GL_DEPTH_TEST)
    glClearColor(0, 0, 0, 1)
    
    # Set up the projection matrix.
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(45, (800 / 600), 0.1, 3000.0)
    glMatrixMode(GL_MODELVIEW)
    
    clock = pygame.time.Clock()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == QUIT:
                running = False
            if event.type == KEYDOWN:
                if event.key == K_LEFT:
                    camera_yaw -= 0.05 * speed_factor
                elif event.key == K_RIGHT:
                    camera_yaw += 0.05 * speed_factor
                elif event.key == K_UP:
                    camera_pitch = min(camera_pitch + 0.05 * speed_factor, math.pi/2 - 0.1)
                elif event.key == K_DOWN:
                    camera_pitch = max(camera_pitch - 0.05 * speed_factor, -math.pi/2 + 0.1)
                elif event.key in (K_PLUS, K_EQUALS):
                    zoom_factor = max(0.1, zoom_factor - 0.1)
                elif event.key == K_MINUS:
                    zoom_factor = min(5.0, zoom_factor + 0.1)
        
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()
        # Compute camera position.
        cam_distance = 1000 * zoom_factor
        cam_x = cam_distance * math.sin(camera_yaw) * math.cos(camera_pitch)
        cam_y = cam_distance * math.sin(camera_pitch) + dome_radius / 2.0
        cam_z = cam_distance * math.cos(camera_yaw) * math.cos(camera_pitch)
        gluLookAt(cam_x, cam_y, cam_z, 0, dome_radius / 2.0, 0, 0, 1, 0)
        
        # Draw scene elements:
        draw_inner_dome()      # Transparent, bulging inner dome
        draw_outer_dome()      # Outer dome (flat circle) for reference
        draw_webcam_feed()     # Webcam feed on a textured circle at the base of the inner dome
        draw_trajectories()    # Trajectory with color transitions
        draw_track_points()    # Permanent track points (yellow inside, red outside)
        draw_red_dots()        # Red dots on the inner dome
        
        pygame.display.flip()
        clock.tick(30)
    cap.release()
    pygame.quit()

if __name__ == "__main__":
    main()

