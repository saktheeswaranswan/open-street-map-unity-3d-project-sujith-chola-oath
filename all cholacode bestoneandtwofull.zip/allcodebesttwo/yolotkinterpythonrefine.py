#pip install opencv-python pygame PyOpenGL PyOpenGL_accelerate
#```) before running this script.

#```python
#!/usr/bin/env python3
import cv2
import numpy as np
import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import math
import random
import tkinter as tk
from tkinter import ttk
import threading

# -------------------------------
# Global parameters (controlled by Tkinter sliders)
# -------------------------------
tk_dome_radius = 300       # Dome radius
tk_grid = 20               # Grid density (# cells along one side)
tk_parabola_range = 100    # Trajectory (curve) range
tk_parabola_height = 50    # Trajectory height offset
tk_traj_exponent = 2       # Trajectory easing exponent
rotation_speed = 0.5       # Additional rotation speed from mouse drag

# New parameters from sliders:
tk_dome_rotation_offset = 0    # Absolute dome rotation (degrees)
tk_zoom_factor = 3.0           # Zoom factor (multiplier)

# -------------------------------
# Tkinter UI setup (runs in a separate thread)
# -------------------------------
def create_tkinter_ui():
    global tk_dome_radius, tk_grid, tk_parabola_range, tk_parabola_height, tk_traj_exponent
    global rotation_speed, tk_dome_rotation_offset, tk_zoom_factor

    root = tk.Tk()
    root.title("Parameter Controls")

    def update_dome_radius(val):
        global tk_dome_radius
        tk_dome_radius = int(float(val))
    def update_grid(val):
        global tk_grid
        tk_grid = int(float(val))
    def update_parabola_range(val):
        global tk_parabola_range
        tk_parabola_range = int(float(val))
    def update_parabola_height(val):
        global tk_parabola_height
        tk_parabola_height = int(float(val))
    def update_traj_exponent(val):
        global tk_traj_exponent
        tk_traj_exponent = float(val)
    def update_rotation_speed(val):
        global rotation_speed
        rotation_speed = float(val)
    def update_dome_rotation_offset(val):
        global tk_dome_rotation_offset
        tk_dome_rotation_offset = float(val)
    def update_zoom_factor(val):
        global tk_zoom_factor
        tk_zoom_factor = float(val)

    ttk.Label(root, text="Dome Radius").pack(padx=10, pady=(10,0))
    dome_slider = ttk.Scale(root, from_=100, to=400, orient="horizontal", command=update_dome_radius)
    dome_slider.set(tk_dome_radius)
    dome_slider.pack(fill="x", padx=10, pady=5)

    ttk.Label(root, text="Grid Density").pack(padx=10, pady=(10,0))
    grid_slider = ttk.Scale(root, from_=5, to=80, orient="horizontal", command=update_grid)
    grid_slider.set(tk_grid)
    grid_slider.pack(fill="x", padx=10, pady=5)

    ttk.Label(root, text="Parabola Range").pack(padx=10, pady=(10,0))
    parabola_range_slider = ttk.Scale(root, from_=50, to=300, orient="horizontal", command=update_parabola_range)
    parabola_range_slider.set(tk_parabola_range)
    parabola_range_slider.pack(fill="x", padx=10, pady=5)

    ttk.Label(root, text="Parabola Height").pack(padx=10, pady=(10,0))
    parabola_height_slider = ttk.Scale(root, from_=10, to=200, orient="horizontal", command=update_parabola_height)
    parabola_height_slider.set(tk_parabola_height)
    parabola_height_slider.pack(fill="x", padx=10, pady=5)

    ttk.Label(root, text="Trajectory Exponent").pack(padx=10, pady=(10,0))
    traj_exponent_slider = ttk.Scale(root, from_=1, to=10, orient="horizontal", command=update_traj_exponent)
    traj_exponent_slider.set(tk_traj_exponent)
    traj_exponent_slider.pack(fill="x", padx=10, pady=5)

    ttk.Label(root, text="Rotation Speed (Mouse)").pack(padx=10, pady=(10,0))
    rotation_speed_slider = ttk.Scale(root, from_=0, to=5, orient="horizontal", command=update_rotation_speed)
    rotation_speed_slider.set(rotation_speed)
    rotation_speed_slider.pack(fill="x", padx=10, pady=5)

    ttk.Label(root, text="Dome Rotation Offset").pack(padx=10, pady=(10,0))
    dome_rotation_slider = ttk.Scale(root, from_=-180, to=180, orient="horizontal", command=update_dome_rotation_offset)
    dome_rotation_slider.set(tk_dome_rotation_offset)
    dome_rotation_slider.pack(fill="x", padx=10, pady=5)

    ttk.Label(root, text="Zoom Factor").pack(padx=10, pady=(10,0))
    zoom_slider = ttk.Scale(root, from_=0.5, to=5.0, orient="horizontal", command=update_zoom_factor)
    zoom_slider.set(tk_zoom_factor)
    zoom_slider.pack(fill="x", padx=10, pady=5)

    root.mainloop()

# Start Tkinter UI in a separate thread.
tk_thread = threading.Thread(target=create_tkinter_ui, daemon=True)
tk_thread.start()

# -------------------------------
# Pygame/OpenGL and OpenCV setup
# -------------------------------
pygame.init()
window_width, window_height = 800, 600
pygame.display.set_mode((window_width, window_height), DOUBLEBUF | OPENGL)
pygame.display.set_caption("3D Dome with Webcam Feed, Grid & Trajectories")

gluPerspective(45, (window_width / window_height), 0.1, 1000.0)
glTranslatef(0.0, 0.0, -600)

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Could not open webcam")
    exit()

texture_id = glGenTextures(1)

def load_texture():
    global texture_id, cap
    ret, frame = cap.read()
    if not ret:
        return False
    frame = cv2.flip(frame, 0)
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame_data = frame.tobytes()
    glBindTexture(GL_TEXTURE_2D, texture_id)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, frame.shape[1], frame.shape[0],
                 0, GL_RGB, GL_UNSIGNED_BYTE, frame_data)
    return True

def draw_textured_circle(radius, slices=100):
    glBegin(GL_TRIANGLE_FAN)
    glTexCoord2f(0.5, 0.5)
    glVertex3f(0, 0, 0)
    for i in range(slices + 1):
        angle = 2 * math.pi * i / slices
        tx = 0.5 + 0.5 * math.cos(angle)
        ty = 0.5 + 0.5 * math.sin(angle)
        glTexCoord2f(tx, ty)
        glVertex3f(radius * math.cos(angle), 0, radius * math.sin(angle))
    glEnd()

def draw_webcam_feed(dome_radius):
    glEnable(GL_TEXTURE_2D)
    if load_texture():
        glBindTexture(GL_TEXTURE_2D, texture_id)
        glColor3f(1, 1, 1)
        draw_textured_circle(dome_radius, slices=100)
    glDisable(GL_TEXTURE_2D)

# Draw semi-transparent square patches covering the dome surface.
def draw_dome_square_patches(dome_radius, grid):
    dx = (2 * dome_radius) / grid
    glEnable(GL_BLEND)
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
    glColor4f(0.0, 0.6, 1.0, 0.1)
    for i in range(grid):
        for j in range(grid):
            x0 = -dome_radius + i * dx
            z0 = -dome_radius + j * dx
            x1 = x0 + dx
            z1 = z0 + dx
            if (x0*x0 + z0*z0 <= dome_radius**2 and
                x1*x1 + z0*z0 <= dome_radius**2 and
                x1*x1 + z1*z1 <= dome_radius**2 and
                x0*x0 + z1*z1 <= dome_radius**2):
                y0 = math.sqrt(max(0, dome_radius**2 - x0*x0 - z0*z0))
                y1 = math.sqrt(max(0, dome_radius**2 - x1*x1 - z0*z0))
                y2 = math.sqrt(max(0, dome_radius**2 - x1*x1 - z1*z1))
                y3 = math.sqrt(max(0, dome_radius**2 - x0*x0 - z1*z1))
                glBegin(GL_QUADS)
                glVertex3f(x0, y0, z0)
                glVertex3f(x1, y1, z0)
                glVertex3f(x1, y2, z1)
                glVertex3f(x0, y3, z1)
                glEnd()
    glDisable(GL_BLEND)

# Draw trajectories from the center to selected points on the dome base.
def draw_trajectories(dome_radius, parabola_range, parabola_height, traj_exponent):
    side = dome_radius * math.sqrt(2)
    valid_dots = []
    for i in range(20):
        for j in range(20):
            dot_x = -side/2 + (i + 0.5) * (side/20)
            dot_z = -side/2 + (j + 0.5) * (side/20)
            if dot_x**2 + dot_z**2 <= dome_radius**2:
                valid_dots.append((dot_x, dot_z))
    selected_dots = random.sample(valid_dots, min(10, len(valid_dots)))
    glLineWidth(2)
    num_segments = 30
    current_time = pygame.time.get_ticks()
    blink = (int(current_time / 200) % 2 == 0)
    for (dot_x, dot_z) in selected_dots:
        p_end = (dot_x, 0, dot_z)
        mag = math.sqrt(dot_x**2 + dot_z**2)
        if mag < 1e-3:
            continue
        dir_x = dot_x / mag
        dir_z = dot_z / mag
        H = parabola_range
        alpha = random.uniform(math.radians(20), math.radians(85))
        vertical_offset = H * math.tan(alpha)
        p0 = (dot_x + dir_x * H, vertical_offset, dot_z + dir_z * H)
        p_control = ((p0[0] + p_end[0]) / 2.0,
                     (p0[1] + p_end[1]) / 2.0 + parabola_height,
                     (p0[2] + p_end[2]) / 2.0)
        glBegin(GL_LINE_STRIP)
        for k in range(num_segments + 1):
            t_linear = k / float(num_segments)
            t = (0.5 * (1 - math.cos(math.pi * t_linear))) ** traj_exponent
            bx = (1-t)**2 * p0[0] + 2*(1-t)*t * p_control[0] + t**2 * p_end[0]
            by = (1-t)**2 * p0[1] + 2*(1-t)*t * p_control[1] + t**2 * p_end[1]
            bz = (1-t)**2 * p0[2] + 2*(1-t)*t * p_control[2] + t**2 * p_end[2]
            if bx**2 + by**2 + bz**2 <= dome_radius**2:
                glColor3f(1, 0, 0) if blink else glColor3f(0.5, 0, 0)
            else:
                glColor3f(0, 1, 0)
            glVertex3f(bx, by, bz)
        glEnd()
        glColor3f(1, 1, 0)
        glBegin(GL_LINES)
        glVertex3f(0, 0, 0)
        glVertex3f(p_end[0], p_end[1], p_end[2])
        glEnd()
    glColor3f(1, 1, 0)
    glBegin(GL_LINES)
    for ang in range(0, 360, 15):
        rad = math.radians(ang)
        x = dome_radius * math.cos(rad)
        z = dome_radius * math.sin(rad)
        glVertex3f(0, 0, 0)
        glVertex3f(x, 0, z)
    glEnd()

# Draw red dots on the dome surface (for example, 20 randomly placed points on the hemisphere).
def draw_red_dots(dome_radius, count=20):
    glColor3f(1, 0, 0)
    glPointSize(8)
    glBegin(GL_POINTS)
    for _ in range(count):
        # Random angles for spherical coordinates.
        theta = random.uniform(0, math.pi/2)  # Only upper hemisphere.
        phi = random.uniform(0, 2*math.pi)
        x = dome_radius * math.sin(theta) * math.cos(phi)
        y = dome_radius * math.cos(theta)
        z = dome_radius * math.sin(theta) * math.sin(phi)
        glVertex3f(x, y, z)
    glEnd()

# Render the scene: set up the camera and draw the dome with webcam feed, grid, trajectories, and red dots.
def render_scene(dome_radius, grid, parabola_range, parabola_height):
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()
    # Use the Tkinter zoom factor for camera distance.
    r = dome_radius * tk_zoom_factor
    center_y = dome_radius / 2.0
    # Camera orientation is controlled by arrow keys (yaw, pitch).
    cam_x = r * math.cos(camera_pitch) * math.cos(camera_yaw)
    cam_y = center_y + r * math.sin(camera_pitch)
    cam_z = r * math.cos(camera_pitch) * math.sin(camera_yaw)
    gluLookAt(cam_x, cam_y, cam_z, 0, center_y, 0, 0, 1, 0)
    glPushMatrix()
    # Combine mouse rotation and slider rotation offset.
    glRotatef(tk_dome_rotation_offset, 0, 1, 0)
    glRotatef(math.degrees(dome_rotation), 0, 1, 0)
    draw_webcam_feed(dome_radius)
    draw_dome_square_patches(dome_radius, grid)
    draw_trajectories(dome_radius, parabola_range, parabola_height, tk_traj_exponent)
    draw_red_dots(dome_radius, count=20)
    glPopMatrix()
    # Optionally, draw a single red dot at the dome top.
    glPushMatrix()
    glColor3f(1, 0, 0)
    glPointSize(10)
    glBegin(GL_POINTS)
    glVertex3f(0, dome_radius, 0)
    glEnd()
    glPopMatrix()

# Global variables for interactive rotation, zoom, and camera control.
dome_rotation = 0.0
rotating = False
prev_mouse_x = 0
camera_yaw = 0.0
camera_pitch = 0.0
speed_factor = 0.5

# A simple on-screen slider class for use within the Pygame window.
class OnScreenSlider:
    def __init__(self, x, y, w, h, min_val, max_val, init_val):
        self.rect = pygame.Rect(x, y, w, h)
        self.min_val = min_val
        self.max_val = max_val
        self.value = init_val
        self.dragging = False

    def update(self, event):
        if event.type == MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                self.dragging = True
                self.set_value_from_mouse(event.pos[0])
        elif event.type == MOUSEBUTTONUP:
            self.dragging = False
        elif event.type == MOUSEMOTION and self.dragging:
            self.set_value_from_mouse(event.pos[0])

    def set_value_from_mouse(self, mouse_x):
        rel = mouse_x - self.rect.x
        fraction = max(0, min(1, rel / self.rect.width))
        self.value = self.min_val + fraction * (self.max_val - self.min_val)

    def draw(self):
        surface = pygame.display.get_surface()
        pygame.draw.rect(surface, (180, 180, 180), self.rect)
        frac = (self.value - self.min_val) / (self.max_val - self.min_val)
        handle_x = self.rect.x + frac * self.rect.width
        handle_rect = pygame.Rect(handle_x - 5, self.rect.y, 10, self.rect.height)
        pygame.draw.rect(surface, (255, 0, 0), handle_rect)

# Main loop: handle events, update on-screen sliders, and render the scene.
def main():
    global dome_rotation, rotating, prev_mouse_x, camera_yaw, camera_pitch, tk_zoom_factor, tk_dome_rotation_offset
    pygame.init()
    pygame.display.set_mode((window_width, window_height), DOUBLEBUF | OPENGL)
    pygame.display.set_caption("3D Dome with Webcam Feed, Grid & Trajectories")
    glEnable(GL_DEPTH_TEST)
    glClearColor(0, 0, 0, 1)
    glMatrixMode(GL_PROJECTION)
    gluPerspective(45, window_width/window_height, 0.1, 1000.0)
    glMatrixMode(GL_MODELVIEW)
    
    # Create on-screen sliders.
    dome_slider = OnScreenSlider(10, 10, 200, 20, 100, 400, 300)
    grid_slider = OnScreenSlider(10, 40, 200, 20, 5, 80, 20)
    parabola_slider = OnScreenSlider(10, 70, 200, 20, 50, 300, 100)
    parabola_height_slider = OnScreenSlider(10, 100, 200, 20, 10, 200, 50)
    zoom_slider = OnScreenSlider(10, 130, 200, 20, 0.5, 5.0, tk_zoom_factor)
    dome_rot_slider = OnScreenSlider(10, 160, 200, 20, -180, 180, tk_dome_rotation_offset)
    
    clock = pygame.time.Clock()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == QUIT:
                running = False
            dome_slider.update(event)
            grid_slider.update(event)
            parabola_slider.update(event)
            parabola_height_slider.update(event)
            zoom_slider.update(event)
            dome_rot_slider.update(event)
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    # Start mouse-drag rotation if click is outside slider areas.
                    if not (dome_slider.rect.collidepoint(event.pos) or
                            grid_slider.rect.collidepoint(event.pos) or
                            parabola_slider.rect.collidepoint(event.pos) or
                            parabola_height_slider.rect.collidepoint(event.pos) or
                            zoom_slider.rect.collidepoint(event.pos) or
                            dome_rot_slider.rect.collidepoint(event.pos)):
                        rotating = True
                        prev_mouse_x = event.pos[0]
            elif event.type == MOUSEBUTTONUP:
                if event.button == 1:
                    rotating = False
            elif event.type == MOUSEMOTION and rotating:
                dx = event.pos[0] - prev_mouse_x
                dome_rotation += dx * 0.005 * speed_factor
                prev_mouse_x = event.pos[0]
            if event.type == pygame.MOUSEWHEEL:
                # Allow mouse wheel to update zoom via the on-screen slider.
                new_zoom = zoom_slider.value - event.y * 0.05
                zoom_slider.value = max(0.5, min(5.0, new_zoom))
            if event.type == KEYDOWN:
                if event.key == K_LEFT:
                    camera_yaw -= 0.05 * speed_factor
                elif event.key == K_RIGHT:
                    camera_yaw += 0.05 * speed_factor
                elif event.key == K_UP:
                    camera_pitch = min(camera_pitch + 0.05 * speed_factor, math.pi/2 - 0.1)
                elif event.key == K_DOWN:
                    camera_pitch = max(camera_pitch - 0.05 * speed_factor, -math.pi/2 + 0.1)
                    
        # Update local parameters from on-screen sliders.
        dome_radius = dome_slider.value
        grid = int(grid_slider.value)
        parabola_range = parabola_slider.value
        parabola_height = parabola_height_slider.value
        tk_zoom_factor = zoom_slider.value
        tk_dome_rotation_offset = dome_rot_slider.value
        
        render_scene(dome_radius, grid, parabola_range, parabola_height)
        pygame.display.flip()
        
        surface = pygame.display.get_surface()
        dome_slider.draw()
        grid_slider.draw()
        parabola_slider.draw()
        parabola_height_slider.draw()
        zoom_slider.draw()
        dome_rot_slider.draw()
        
        clock.tick(30)
    cap.release()
    pygame.quit()

if __name__ == "__main__":
    main()

