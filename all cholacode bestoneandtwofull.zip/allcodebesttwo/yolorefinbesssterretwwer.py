#!/usr/bin/env python3
import cv2
import numpy as np
import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import math
import random

# -------------------------------
# Global parameters (adjust as desired)
# -------------------------------
dome_radius = 300        # Dome radius
parabola_range = 100     # Trajectory (curve) range
parabola_height = 50     # Trajectory height offset
traj_exponent = 2        # Trajectory easing exponent
mouse_rotation_speed = 0.5  # Additional rotation speed from mouse drag

# Dome transformation and camera parameters.
dome_rotation_offset = 0   # Absolute dome rotation offset (degrees)
zoom_factor = 3.0          # Zoom factor (multiplier)
camera_yaw = 0.0           # Camera yaw (controlled by arrow keys)
camera_pitch = 0.0         # Camera pitch (controlled by arrow keys)
dome_rotation = 0.0        # Additional dome rotation (via right-mouse drag)
speed_factor = 0.5         # General speed factor for rotations

# Global list to store yellow track points (permanent trace)
yellow_tracks = []

# -------------------------------
# Red dot initialization – points on the dome (upper hemisphere)
# -------------------------------
red_dots = []  # Each dot: {"pos": (x,y,z), "color": (r,g,b)}
num_red_dots = 20
for _ in range(num_red_dots):
    theta = random.uniform(0, math.pi/2)  # Only upper hemisphere.
    phi = random.uniform(0, 2*math.pi)
    x = dome_radius * math.sin(theta) * math.cos(phi)
    y = dome_radius * math.cos(theta)
    z = dome_radius * math.sin(theta) * math.sin(phi)
    red_dots.append({"pos": (x, y, z), "color": (1, 0, 0)})  # Initially red.

# -------------------------------
# Pygame/OpenGL and OpenCV setup
# -------------------------------
pygame.init()
window_width, window_height = 800, 600
pygame.display.set_mode((window_width, window_height), DOUBLEBUF | OPENGL)
pygame.display.set_caption("Transparent 3D Dome with Webcam Feed, Red Dots & Live Detection")

gluPerspective(45, window_width/window_height, 0.1, 1000.0)
glTranslatef(0.0, 0.0, -600)

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Could not open webcam")
    exit()
texture_id = glGenTextures(1)

def load_texture():
    ret, frame = cap.read()
    if not ret:
        return False
    frame = cv2.flip(frame, 0)
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame_data = frame.tobytes()
    glBindTexture(GL_TEXTURE_2D, texture_id)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, frame.shape[1], frame.shape[0],
                 0, GL_RGB, GL_UNSIGNED_BYTE, frame_data)
    return True

def draw_textured_circle(radius, slices=100):
    glBegin(GL_TRIANGLE_FAN)
    glTexCoord2f(0.5, 0.5)
    glVertex3f(0, 0, 0)
    for i in range(slices + 1):
        angle = 2 * math.pi * i / slices
        tx = 0.5 + 0.5 * math.cos(angle)
        ty = 0.5 + 0.5 * math.sin(angle)
        glTexCoord2f(tx, ty)
        glVertex3f(radius * math.cos(angle), 0, radius * math.sin(angle))
    glEnd()

# Draw the webcam feed as a textured circle with 50% opacity (transparent dome).
def draw_webcam_feed(dome_radius):
    glEnable(GL_TEXTURE_2D)
    if load_texture():
        glBindTexture(GL_TEXTURE_2D, texture_id)
        glColor4f(1, 1, 1, 0.5)  # 50% opacity
        draw_textured_circle(dome_radius, slices=100)
    glDisable(GL_TEXTURE_2D)

# -------------------------------
# Trajectories with permanent yellow tracks
# -------------------------------
def draw_trajectories(dome_radius, parabola_range, parabola_height, traj_exponent):
    global yellow_tracks
    side = dome_radius * math.sqrt(2)
    valid_dots = []
    for i in range(20):
        for j in range(20):
            dot_x = -side/2 + (i + 0.5) * (side/20)
            dot_z = -side/2 + (j + 0.5) * (side/20)
            if dot_x**2 + dot_z**2 <= dome_radius**2:
                valid_dots.append((dot_x, dot_z))
    selected_dots = random.sample(valid_dots, min(10, len(valid_dots)))
    glLineWidth(2)
    num_segments = 30
    blink = (int(pygame.time.get_ticks() / 200) % 2 == 0)
    sample_points = []
    for (dot_x, dot_z) in selected_dots:
        p_end = (dot_x, 0, dot_z)
        mag = math.sqrt(dot_x**2 + dot_z**2)
        if mag < 1e-3:
            continue
        dir_x = dot_x / mag
        dir_z = dot_z / mag
        H = parabola_range
        alpha = random.uniform(math.radians(20), math.radians(85))
        vertical_offset = H * math.tan(alpha)
        p0 = (dot_x + dir_x * H, vertical_offset, dot_z + dir_z * H)
        p_control = ((p0[0] + p_end[0]) / 2.0,
                     (p0[1] + p_end[1]) / 2.0 + parabola_height,
                     (p0[2] + p_end[2]) / 2.0)
        trajectory_samples = []
        glBegin(GL_LINE_STRIP)
        for k in range(num_segments + 1):
            t_linear = k / float(num_segments)
            t = (0.5 * (1 - math.cos(math.pi * t_linear))) ** traj_exponent
            bx = (1-t)**2 * p0[0] + 2*(1-t)*t * p_control[0] + t**2 * p_end[0]
            by = (1-t)**2 * p0[1] + 2*(1-t)*t * p_control[1] + t**2 * p_end[1]
            bz = (1-t)**2 * p0[2] + 2*(1-t)*t * p_control[2] + t**2 * p_end[2]
            trajectory_samples.append((bx, by, bz))
            if bx**2 + by**2 + bz**2 <= dome_radius**2:
                glColor3f(1, 0, 0) if blink else glColor3f(0.5, 0, 0)
            else:
                glColor3f(0, 1, 0)
            glVertex3f(bx, by, bz)
        glEnd()
        sample_points.extend(trajectory_samples)
    epsilon = 5.0
    for (bx, by, bz) in sample_points:
        dome_y = math.sqrt(max(0, dome_radius**2 - bx**2 - bz**2))
        if abs(by - dome_y) < epsilon:
            add_point = True
            for (tx, ty, tz) in yellow_tracks:
                if math.sqrt((bx-tx)**2 + (by-ty)**2 + (bz-tz)**2) < 5:
                    add_point = False
                    break
            if add_point:
                yellow_tracks.append((bx, by, bz))

def draw_track_points():
    glColor3f(1, 1, 0)  # Yellow for permanent tracks
    glPointSize(6)
    glBegin(GL_POINTS)
    for pt in yellow_tracks:
        glVertex3fv(pt)
    glEnd()

# -------------------------------
# Red dots and interaction
# -------------------------------
def draw_red_dots():
    glPointSize(8)
    glBegin(GL_POINTS)
    for dot in red_dots:
        glColor3fv(dot["color"])
        glVertex3fv(dot["pos"])
    glEnd()

# Helper: Project a 3D point to screen coordinates.
def project(point):
    modelview = glGetDoublev(GL_MODELVIEW_MATRIX)
    projection = glGetDoublev(GL_PROJECTION_MATRIX)
    viewport = glGetIntegerv(GL_VIEWPORT)
    winX, winY, winZ = gluProject(point[0], point[1], point[2],
                                   modelview, projection, viewport)
    return winX, viewport[3] - winY, winZ

def render_scene(dome_radius, parabola_range, parabola_height):
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()
    # Set camera using zoom_factor.
    r = dome_radius * zoom_factor
    center_y = dome_radius / 2.0
    cam_x = r * math.cos(camera_pitch) * math.cos(camera_yaw)
    cam_y = center_y + r * math.sin(camera_pitch)
    cam_z = r * math.cos(camera_pitch) * math.sin(camera_yaw)
    gluLookAt(cam_x, cam_y, cam_z, 0, center_y, 0, 0, 1, 0)
    glPushMatrix()
    glRotatef(dome_rotation_offset, 0, 1, 0)
    glRotatef(math.degrees(dome_rotation), 0, 1, 0)
    draw_webcam_feed(dome_radius)
    draw_trajectories(dome_radius, parabola_range, parabola_height, traj_exponent)
    draw_track_points()  # Draw permanent yellow tracks.
    draw_red_dots()
    glPopMatrix()
    glPushMatrix()
    glColor3f(1, 0, 0)
    glPointSize(10)
    glBegin(GL_POINTS)
    glVertex3f(0, dome_radius, 0)
    glEnd()
    glPopMatrix()

# -------------------------------
# 2D Webcam Feed (Live Detection) Display
# -------------------------------
def draw_webcam_feed_2d():
    if not load_texture():
        return
    glMatrixMode(GL_PROJECTION)
    glPushMatrix()
    glLoadIdentity()
    glOrtho(0, window_width, 0, window_height, -1, 1)
    glMatrixMode(GL_MODELVIEW)
    glPushMatrix()
    glLoadIdentity()
    glEnable(GL_TEXTURE_2D)
    glBindTexture(GL_TEXTURE_2D, texture_id)
    glColor3f(1, 1, 1)
    quad_width, quad_height = 200, 150
    x, y = 10, 10
    glBegin(GL_QUADS)
    glTexCoord2f(0, 0); glVertex2f(x, y)
    glTexCoord2f(1, 0); glVertex2f(x + quad_width, y)
    glTexCoord2f(1, 1); glVertex2f(x + quad_width, y + quad_height)
    glTexCoord2f(0, 1); glVertex2f(x, y + quad_height)
    glEnd()
    glDisable(GL_TEXTURE_2D)
    glPopMatrix()
    glMatrixMode(GL_PROJECTION)
    glPopMatrix()
    glMatrixMode(GL_MODELVIEW)

# -------------------------------
# Global variables for interactive control.
# -------------------------------
dome_rotation = 0.0
rotating = False
prev_mouse_x = 0
camera_yaw = 0.0
camera_pitch = 0.0

def main():
    global dome_rotation, rotating, prev_mouse_x, camera_yaw, camera_pitch, zoom_factor, dome_rotation_offset
    pygame.init()
    pygame.display.set_mode((window_width, window_height), DOUBLEBUF | OPENGL)
    pygame.display.set_caption("Transparent 3D Dome with Webcam Feed, Red Dots & Live Detection")
    glEnable(GL_DEPTH_TEST)
    glClearColor(0, 0, 0, 1)
    glMatrixMode(GL_PROJECTION)
    gluPerspective(45, window_width/window_height, 0.1, 1000.0)
    glMatrixMode(GL_MODELVIEW)
    
    clock = pygame.time.Clock()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == QUIT:
                running = False
            # On left mouse click, check if a red dot was clicked.
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    mx, my = event.pos
                    for dot in red_dots:
                        sx, sy, _ = project(dot["pos"])
                        if math.hypot(sx - mx, sy - my) < 10:
                            dot["color"] = (1, 1, 0)  # Turn yellow.
            # Right mouse button drag rotates the dome.
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 3:
                    rotating = True
                    prev_mouse_x = event.pos[0]
            if event.type == MOUSEBUTTONUP:
                if event.button == 3:
                    rotating = False
            if event.type == MOUSEMOTION and rotating:
                dx = event.pos[0] - prev_mouse_x
                dome_rotation += dx * 0.005 * speed_factor
                prev_mouse_x = event.pos[0]
            # Mouse wheel adjusts zoom.
            if event.type == pygame.MOUSEWHEEL:
                zoom_factor = max(0.5, min(5.0, zoom_factor - event.y * 0.1))
            # Arrow keys control camera orientation.
            if event.type == KEYDOWN:
                if event.key == K_LEFT:
                    camera_yaw -= 0.05 * speed_factor
                elif event.key == K_RIGHT:
                    camera_yaw += 0.05 * speed_factor
                elif event.key == K_UP:
                    camera_pitch = min(camera_pitch + 0.05 * speed_factor, math.pi/2 - 0.1)
                elif event.key == K_DOWN:
                    camera_pitch = max(camera_pitch - 0.05 * speed_factor, -math.pi/2 + 0.1)
                    
        render_scene(dome_radius, parabola_range, parabola_height)
        draw_webcam_feed_2d()  # 2D live webcam feed overlay.
        pygame.display.flip()
        clock.tick(30)
    cap.release()
    pygame.quit()

if __name__ == "__main__":
    main()

