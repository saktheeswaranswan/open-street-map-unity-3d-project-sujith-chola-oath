#!/usr/bin/env python3
import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import math
import random

# -------------------------------
# Global parameters
# -------------------------------
dome_radius = 300
second_dome_radius = 310  # Second dome, 10 units larger
parabola_range = 100
parabola_height = 50
traj_exponent = 2
mouse_rotation_speed = 0.5

# Dome transformation and camera parameters.
dome_rotation_offset = 0
zoom_factor = 3.0
camera_yaw = 0.0
camera_pitch = 0.0
dome_rotation = 0.0
speed_factor = 0.5

# Track points lists
yellow_tracks = []
red_tracks = []
green_tracks = []

# Red dots initialization (upper hemisphere)
red_dots = []  
num_red_dots = 20
for _ in range(num_red_dots):
    theta = random.uniform(0, math.pi/2)
    phi = random.uniform(0, 2*math.pi)
    x = dome_radius * math.sin(theta) * math.cos(phi)
    y = dome_radius * math.cos(theta)
    z = dome_radius * math.sin(theta) * math.sin(phi)
    red_dots.append({"pos": (x, y, z), "color": (1, 0, 0)})  # Initially red.

# -------------------------------
# Drawing functions
# -------------------------------
def draw_dome(radius):
    glColor3f(1, 1, 1)
    glBegin(GL_LINE_LOOP)
    for i in range(100):
        angle = 2 * math.pi * i / 100
        glVertex3f(radius * math.cos(angle), 0, radius * math.sin(angle))
    glEnd()

def draw_trajectories():
    global yellow_tracks, red_tracks, green_tracks
    num_segments = 30
    blink = (int(pygame.time.get_ticks() / 200) % 2 == 0)
    # Draw 10 trajectories
    for _ in range(10):
        # Pick a random point inside the first dome's projection
        x, z = random.uniform(-dome_radius, dome_radius), random.uniform(-dome_radius, dome_radius)
        if x**2 + z**2 > dome_radius**2:
            continue
        start = (x, 0, z)
        end = (-x, 0, -z)
        control = ((start[0] + end[0]) / 2, parabola_height, (start[2] + end[2]) / 2)
        glBegin(GL_LINE_STRIP)
        for k in range(num_segments + 1):
            t = k / num_segments
            bx = (1-t)**2 * start[0] + 2*(1-t)*t * control[0] + t**2 * end[0]
            by = (1-t)**2 * start[1] + 2*(1-t)*t * control[1] + t**2 * end[1]
            bz = (1-t)**2 * start[2] + 2*(1-t)*t * control[2] + t**2 * end[2]
            glColor3f(1, 0, 0) if blink else glColor3f(0.5, 0, 0)
            glVertex3f(bx, by, bz)
            
            # Interaction tracking based on xz-plane distance
            radial_sq = bx**2 + bz**2
            if radial_sq <= dome_radius**2:
                if (bx, by, bz) not in yellow_tracks:
                    yellow_tracks.append((bx, by, bz))
            elif radial_sq <= second_dome_radius**2:
                if (bx, by, bz) not in green_tracks:
                    green_tracks.append((bx, by, bz))
        glEnd()
    # Convert yellow tracks to red once they have entered the second dome.
    for pt in yellow_tracks.copy():
        if pt in green_tracks:
            red_tracks.append(pt)
            yellow_tracks.remove(pt)

def draw_track_points():
    glPointSize(6)
    # Draw yellow track points
    glColor3f(1, 1, 0)
    glBegin(GL_POINTS)
    for pt in yellow_tracks:
        glVertex3fv(pt)
    glEnd()
    # Draw red track points
    glColor3f(1, 0, 0)
    glBegin(GL_POINTS)
    for pt in red_tracks:
        glVertex3fv(pt)
    glEnd()
    # Draw green track points
    glColor3f(0, 1, 0)
    glBegin(GL_POINTS)
    for pt in green_tracks:
        glVertex3fv(pt)
    glEnd()

def draw_red_dots():
    glPointSize(8)
    glBegin(GL_POINTS)
    for dot in red_dots:
        glColor3fv(dot["color"])
        glVertex3fv(dot["pos"])
    glEnd()

# -------------------------------
# Main loop and OpenGL setup
# -------------------------------
def main():
    global camera_yaw, camera_pitch, zoom_factor
    pygame.init()
    display = pygame.display.set_mode((800, 600), DOUBLEBUF | OPENGL)
    pygame.display.set_caption("Double Dome Trajectory Interaction")
    glEnable(GL_DEPTH_TEST)
    glClearColor(0, 0, 0, 1)
    
    gluPerspective(45, 800/600, 0.1, 1000.0)
    glTranslatef(0.0, 0.0, -600)
    
    clock = pygame.time.Clock()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == QUIT:
                running = False
            if event.type == KEYDOWN:
                if event.key == K_LEFT:
                    camera_yaw -= 0.05 * speed_factor
                elif event.key == K_RIGHT:
                    camera_yaw += 0.05 * speed_factor
                elif event.key == K_UP:
                    camera_pitch = min(camera_pitch + 0.05 * speed_factor, math.pi/2 - 0.1)
                elif event.key == K_DOWN:
                    camera_pitch = max(camera_pitch - 0.05 * speed_factor, -math.pi/2 + 0.1)
                elif event.key in (K_EQUALS, K_PLUS):  # Zoom in
                    zoom_factor = max(0.5, zoom_factor - 0.1)
                elif event.key == K_MINUS:          # Zoom out
                    zoom_factor = min(5.0, zoom_factor + 0.1)
        
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()
        # Calculate camera position based on current zoom and angles.
        r = dome_radius * zoom_factor
        cam_x = r * math.cos(camera_pitch) * math.cos(camera_yaw)
        cam_y = dome_radius / 2.0 + r * math.sin(camera_pitch)
        cam_z = r * math.cos(camera_pitch) * math.sin(camera_yaw)
        gluLookAt(cam_x, cam_y, cam_z, 0, dome_radius / 2.0, 0, 0, 1, 0)
        
        # Draw the two domes, trajectories, track points, and red dots.
        draw_dome(dome_radius)
        draw_dome(second_dome_radius)
        draw_trajectories()
        draw_track_points()
        draw_red_dots()
        
        pygame.display.flip()
        clock.tick(30)
    pygame.quit()

if __name__ == "__main__":
    main()

