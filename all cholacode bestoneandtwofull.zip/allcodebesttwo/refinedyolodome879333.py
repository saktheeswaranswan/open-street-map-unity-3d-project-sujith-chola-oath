#!/usr/bin/env python3
import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import math
import random

# -------------------------------
# Global parameters
# -------------------------------
dome_radius = 300
second_dome_radius = 310  # Second dome, 10 units larger
speed_factor = 0.5

# Camera parameters
zoom_factor = 1.0
camera_yaw = 0.0
camera_pitch = 0.0

# Track points lists
yellow_tracks = []
red_tracks = []
green_tracks = []

# Red dots initialization (upper hemisphere)
red_dots = []
num_red_dots = 20
for _ in range(num_red_dots):
    theta = random.uniform(0, math.pi/2)
    phi = random.uniform(0, 2 * math.pi)
    x = dome_radius * math.sin(theta) * math.cos(phi)
    y = dome_radius * math.cos(theta)
    z = dome_radius * math.sin(theta) * math.sin(phi)
    red_dots.append({"pos": (x, y, z), "color": (1, 0, 0)})  # Initially red.

# -------------------------------
# Drawing functions
# -------------------------------
def draw_dome(radius):
    glColor3f(1, 1, 1)
    glBegin(GL_LINE_LOOP)
    for i in range(100):
        angle = 2 * math.pi * i / 100
        glVertex3f(radius * math.cos(angle), 0, radius * math.sin(angle))
    glEnd()

def draw_trajectories():
    global yellow_tracks, red_tracks, green_tracks
    num_segments = 30
    # Blink effect toggled every 200 ms
    blink = (int(pygame.time.get_ticks() / 200) % 2 == 0)
    # Draw 10 trajectories
    for _ in range(10):
        x = random.uniform(-dome_radius, dome_radius)
        z = random.uniform(-dome_radius, dome_radius)
        if x**2 + z**2 > dome_radius**2:
            continue
        start = (x, 0, z)
        end = (-x, 0, -z)
        control = ((start[0] + end[0]) / 2, 50, (start[2] + end[2]) / 2)
        glBegin(GL_LINE_STRIP)
        for k in range(num_segments + 1):
            t = k / num_segments
            bx = (1 - t)**2 * start[0] + 2 * (1 - t) * t * control[0] + t**2 * end[0]
            by = (1 - t)**2 * start[1] + 2 * (1 - t) * t * control[1] + t**2 * end[1]
            bz = (1 - t)**2 * start[2] + 2 * (1 - t) * t * control[2] + t**2 * end[2]
            if blink:
                glColor3f(1, 0, 0)
            else:
                glColor3f(0.5, 0, 0)
            glVertex3f(bx, by, bz)
            # Track the trajectory points based on distance from center (xz-plane)
            radial_sq = bx**2 + bz**2
            if radial_sq <= dome_radius**2:
                if (bx, by, bz) not in yellow_tracks:
                    yellow_tracks.append((bx, by, bz))
            elif radial_sq <= second_dome_radius**2:
                if (bx, by, bz) not in green_tracks:
                    green_tracks.append((bx, by, bz))
        glEnd()
    # Convert yellow to red if they have entered the second dome.
    for pt in yellow_tracks.copy():
        if pt in green_tracks:
            red_tracks.append(pt)
            yellow_tracks.remove(pt)

def draw_track_points():
    glPointSize(6)
    # Draw yellow track points
    glColor3f(1, 1, 0)
    glBegin(GL_POINTS)
    for pt in yellow_tracks:
        glVertex3fv(pt)
    glEnd()
    # Draw red track points
    glColor3f(1, 0, 0)
    glBegin(GL_POINTS)
    for pt in red_tracks:
        glVertex3fv(pt)
    glEnd()
    # Draw green track points
    glColor3f(0, 1, 0)
    glBegin(GL_POINTS)
    for pt in green_tracks:
        glVertex3fv(pt)
    glEnd()

def draw_red_dots():
    glPointSize(8)
    glBegin(GL_POINTS)
    for dot in red_dots:
        glColor3fv(dot["color"])
        glVertex3fv(dot["pos"])
    glEnd()

# -------------------------------
# Main loop and OpenGL setup
# -------------------------------
def main():
    global camera_yaw, camera_pitch, zoom_factor
    pygame.init()
    screen = pygame.display.set_mode((800, 600), DOUBLEBUF | OPENGL)
    pygame.display.set_caption("Double Dome Trajectory Interaction")
    
    # Setup OpenGL states
    glEnable(GL_DEPTH_TEST)
    glClearColor(0, 0, 0, 1)
    
    # Setup projection matrix
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(45, (800/600), 0.1, 2000.0)
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()
    
    clock = pygame.time.Clock()
    running = True
    while running:
        # Event processing
        for event in pygame.event.get():
            if event.type == QUIT:
                running = False
            if event.type == KEYDOWN:
                if event.key == K_LEFT:
                    camera_yaw -= 0.05 * speed_factor
                elif event.key == K_RIGHT:
                    camera_yaw += 0.05 * speed_factor
                elif event.key == K_UP:
                    camera_pitch = min(camera_pitch + 0.05 * speed_factor, math.pi/2 - 0.1)
                elif event.key == K_DOWN:
                    camera_pitch = max(camera_pitch - 0.05 * speed_factor, -math.pi/2 + 0.1)
                elif event.key in (K_PLUS, K_EQUALS):  # Zoom in
                    zoom_factor = max(0.1, zoom_factor - 0.1)
                elif event.key == K_MINUS:           # Zoom out
                    zoom_factor = min(5.0, zoom_factor + 0.1)
        
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()
        
        # Compute camera position so that the domes are in view.
        # Increase the base distance to ensure everything appears.
        cam_distance = 800 * zoom_factor
        cam_x = cam_distance * math.sin(camera_yaw) * math.cos(camera_pitch)
        cam_y = cam_distance * math.sin(camera_pitch) + dome_radius / 2.0
        cam_z = cam_distance * math.cos(camera_yaw) * math.cos(camera_pitch)
        gluLookAt(cam_x, cam_y, cam_z, 0, dome_radius / 2.0, 0, 0, 1, 0)
        
        # Draw scene elements
        draw_dome(dome_radius)
        draw_dome(second_dome_radius)
        draw_trajectories()
        draw_track_points()
        draw_red_dots()
        
        pygame.display.flip()
        clock.tick(30)
    pygame.quit()

if __name__ == '__main__':
    main()

