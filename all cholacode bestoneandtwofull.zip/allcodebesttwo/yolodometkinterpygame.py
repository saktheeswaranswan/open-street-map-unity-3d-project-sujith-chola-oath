#!/usr/bin/env python3
import cv2
import numpy as np
import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import math
import random
import tkinter as tk
from tkinter import ttk
import threading

# -------------------------------
# Global parameters (controlled by Tkinter sliders)
# -------------------------------
tk_dome_radius = 300       # Dome radius
tk_grid = 20               # Grid density (number of cells along one side)
tk_parabola_range = 100    # Parabolic trajectory range
tk_parabola_height = 50    # Parabolic trajectory height offset
tk_traj_exponent = 2       # Trajectory easing exponent
rotation_speed = 0.5       # Rotation speed (degrees per frame)

# -------------------------------
# Tkinter UI setup
# -------------------------------
def create_tkinter_ui():
    global tk_dome_radius, tk_grid, tk_parabola_range, tk_parabola_height, tk_traj_exponent, rotation_speed

    root = tk.Tk()
    root.title("Parameter Controls")

    # Callback functions use int(float(val)) for proper conversion
    def update_dome_radius(val):
        global tk_dome_radius
        tk_dome_radius = int(float(val))
    def update_grid(val):
        global tk_grid
        tk_grid = int(float(val))
    def update_parabola_range(val):
        global tk_parabola_range
        tk_parabola_range = int(float(val))
    def update_parabola_height(val):
        global tk_parabola_height
        tk_parabola_height = int(float(val))
    def update_traj_exponent(val):
        global tk_traj_exponent
        tk_traj_exponent = float(val)
    def update_rotation_speed(val):
        global rotation_speed
        rotation_speed = float(val)

    # Create sliders for each parameter.
    ttk.Label(root, text="Dome Radius").pack(padx=10, pady=(10,0))
    dome_slider = ttk.Scale(root, from_=100, to=400, orient="horizontal", command=update_dome_radius)
    dome_slider.set(tk_dome_radius)
    dome_slider.pack(fill="x", padx=10, pady=5)

    ttk.Label(root, text="Grid Density").pack(padx=10, pady=(10,0))
    grid_slider = ttk.Scale(root, from_=5, to=80, orient="horizontal", command=update_grid)
    grid_slider.set(tk_grid)
    grid_slider.pack(fill="x", padx=10, pady=5)

    ttk.Label(root, text="Parabola Range").pack(padx=10, pady=(10,0))
    parabola_range_slider = ttk.Scale(root, from_=50, to=300, orient="horizontal", command=update_parabola_range)
    parabola_range_slider.set(tk_parabola_range)
    parabola_range_slider.pack(fill="x", padx=10, pady=5)

    ttk.Label(root, text="Parabola Height").pack(padx=10, pady=(10,0))
    parabola_height_slider = ttk.Scale(root, from_=10, to=200, orient="horizontal", command=update_parabola_height)
    parabola_height_slider.set(tk_parabola_height)
    parabola_height_slider.pack(fill="x", padx=10, pady=5)

    ttk.Label(root, text="Trajectory Exponent").pack(padx=10, pady=(10,0))
    traj_exponent_slider = ttk.Scale(root, from_=1, to=10, orient="horizontal", command=update_traj_exponent)
    traj_exponent_slider.set(tk_traj_exponent)
    traj_exponent_slider.pack(fill="x", padx=10, pady=5)

    ttk.Label(root, text="Rotation Speed").pack(padx=10, pady=(10,0))
    rotation_speed_slider = ttk.Scale(root, from_=0, to=5, orient="horizontal", command=update_rotation_speed)
    rotation_speed_slider.set(rotation_speed)
    rotation_speed_slider.pack(fill="x", padx=10, pady=5)

    root.mainloop()

# Run Tkinter UI in a separate thread.
tk_thread = threading.Thread(target=create_tkinter_ui, daemon=True)
tk_thread.start()

# -------------------------------
# Pygame/OpenGL and OpenCV setup
# -------------------------------
pygame.init()
window_width = 800
window_height = 600
pygame.display.set_mode((window_width, window_height), DOUBLEBUF | OPENGL)
pygame.display.set_caption("Dome with Live Webcam Feed (Tkinter Controlled)")

# Set up OpenGL perspective.
gluPerspective(45, (window_width / window_height), 0.1, 1000.0)
# Move camera back so the scene is visible.
glTranslatef(0.0, 0.0, -600)

# Initialize webcam capture (using OpenCV).
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Could not open webcam")
    exit()

# Create an OpenGL texture ID for the webcam feed.
textureID = glGenTextures(1)

def update_texture():
    ret, frame = cap.read()
    if not ret:
        return
    # Flip frame vertically and convert from BGR to RGB.
    frame = cv2.flip(frame, 0)
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame_data = frame.tobytes()
    glBindTexture(GL_TEXTURE_2D, textureID)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, frame.shape[1], frame.shape[0],
                 0, GL_RGB, GL_UNSIGNED_BYTE, frame_data)

def draw_textured_circle(radius, slices=100):
    glBegin(GL_TRIANGLE_FAN)
    glTexCoord2f(0.5, 0.5)
    glVertex3f(0, 0, 0)
    for i in range(slices + 1):
        angle = 2 * math.pi * i / slices
        tx = 0.5 + 0.5 * math.cos(angle)
        ty = 0.5 + 0.5 * math.sin(angle)
        glTexCoord2f(tx, ty)
        glVertex3f(radius * math.cos(angle), 0, radius * math.sin(angle))
    glEnd()

def draw_webcam_feed(dome_radius):
    glEnable(GL_TEXTURE_2D)
    update_texture()
    glBindTexture(GL_TEXTURE_2D, textureID)
    glColor3f(1, 1, 1)
    draw_textured_circle(dome_radius, slices=100)
    glDisable(GL_TEXTURE_2D)

def draw_dome_square_patches(dome_radius, grid):
    dx = (2 * dome_radius) / grid
    glEnable(GL_BLEND)
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
    glColor4f(0.0, 0.6, 1.0, 0.1)
    for i in range(grid):
        for j in range(grid):
            x0 = -dome_radius + i * dx
            z0 = -dome_radius + j * dx
            x1 = x0 + dx
            z1 = z0 + dx
            if (x0*x0 + z0*z0 <= dome_radius**2 and
                x1*x1 + z0*z0 <= dome_radius**2 and
                x1*x1 + z1*z1 <= dome_radius**2 and
                x0*x0 + z1*z1 <= dome_radius**2):
                y0 = math.sqrt(dome_radius**2 - x0*x0 - z0*z0)
                y1 = math.sqrt(dome_radius**2 - x1*x1 - z0*z0)
                y2 = math.sqrt(dome_radius**2 - x1*x1 - z1*z1)
                y3 = math.sqrt(dome_radius**2 - x0*x0 - z1*z1)
                glBegin(GL_QUADS)
                glVertex3f(x0, y0, z0)
                glVertex3f(x1, y1, z0)
                glVertex3f(x1, y2, z1)
                glVertex3f(x0, y3, z1)
                glEnd()
    glDisable(GL_BLEND)

def draw_trajectories(dome_radius, parabola_range, parabola_height, traj_exponent):
    # Define a grid over the dome's circular base.
    side = dome_radius * math.sqrt(2)
    valid_dots = []
    for i in range(20):
        for j in range(20):
            dot_x = -side/2 + (i + 0.5) * (side/20)
            dot_z = -side/2 + (j + 0.5) * (side/20)
            if dot_x**2 + dot_z**2 <= dome_radius**2:
                valid_dots.append((dot_x, dot_z))
    # Randomly select up to 10 dots.
    if len(valid_dots) > 10:
        selected_dots = random.sample(valid_dots, 10)
    else:
        selected_dots = valid_dots

    glLineWidth(2)
    num_segments = 30
    current_time = pygame.time.get_ticks()
    blink = (int(current_time / 200) % 2 == 0)

    for (dot_x, dot_z) in selected_dots:
        p_end = (dot_x, 0, dot_z)
        mag = math.sqrt(dot_x**2 + dot_z**2)
        if mag < 1e-3:
            continue
        dir_x = dot_x / mag
        dir_z = dot_z / mag
        H = parabola_range
        alpha = random.uniform(math.radians(20), math.radians(85))
        vertical_offset = H * math.tan(alpha)
        p0 = (dot_x + dir_x * H, vertical_offset, dot_z + dir_z * H)
        p_control = ((p0[0] + p_end[0]) / 2.0,
                     (p0[1] + p_end[1]) / 2.0 + parabola_height,
                     (p0[2] + p_end[2]) / 2.0)
        glBegin(GL_LINE_STRIP)
        for k in range(num_segments + 1):
            t_linear = k / float(num_segments)
            # Ease–in–out interpolation
            t = (0.5 * (1 - math.cos(math.pi * t_linear))) ** traj_exponent
            bx = (1 - t)**2 * p0[0] + 2 * (1 - t) * t * p_control[0] + t**2 * p_end[0]
            by = (1 - t)**2 * p0[1] + 2 * (1 - t) * t * p_control[1] + t**2 * p_end[1]
            bz = (1 - t)**2 * p0[2] + 2 * (1 - t) * t * p_control[2] + t**2 * p_end[2]
            if bx**2 + by**2 + bz**2 <= dome_radius**2:
                glColor3f(1, 0, 0) if blink else glColor3f(0.5, 0, 0)
            else:
                glColor3f(0, 1, 0)
            glVertex3f(bx, by, bz)
        glEnd()
        # Draw a yellow reference line from the origin to the dot.
        glColor3f(1, 1, 0)
        glBegin(GL_LINES)
        glVertex3f(0, 0, 0)
        glVertex3f(p_end[0], p_end[1], p_end[2])
        glEnd()

def render_scene(dome_radius, grid, parabola_range, parabola_height, traj_exponent, angle):
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()

    # Simple camera setup.
    r = dome_radius * 3.0
    center_y = dome_radius / 2.0
    # Fixed camera orientation for simplicity.
    cam_x = r * math.cos(0) * math.cos(0)
    cam_y = center_y + r * math.sin(0)
    cam_z = r * math.cos(0) * math.sin(0)
    gluLookAt(cam_x, cam_y, cam_z, 0, center_y, 0, 0, 1, 0)

    glPushMatrix()
    glRotatef(angle, 0, 1, 0)
    draw_webcam_feed(dome_radius)
    draw_dome_square_patches(dome_radius, grid)
    draw_trajectories(dome_radius, parabola_range, parabola_height, traj_exponent)
    glPopMatrix()

# Main loop
clock = pygame.time.Clock()
angle = 0
running = True
while running:
    for event in pygame.event.get():
        if event.type == QUIT:
            running = False

    # Increment rotation angle using the current rotation_speed from Tkinter.
    angle += rotation_speed

    render_scene(tk_dome_radius, tk_grid, tk_parabola_range, tk_parabola_height, tk_traj_exponent, angle)
    pygame.display.flip()
    clock.tick(30)

cap.release()
pygame.quit()

